<?php
session_start();
include "../config/db.php";

// Check if admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$result = null;

if ($action === 'test_push') {
    // Send test push
    include "../api/send_push.php";
    $result = send_push_notifications(
        "Test Notification",
        "This is a test push notification from Classbuzz."
    );
}

if ($action === 'check_reminders') {
    // Check reminders
    include "../api/send_push.php";
    include "../api/check_reminders.php";
}

// Get statistics
$tokenCount = 0;
$tokenRes = $conn->query("SELECT COUNT(*) as cnt FROM fcm_tokens");
if ($tokenRes) {
    $row = $tokenRes->fetch_assoc();
    $tokenCount = (int)$row['cnt'];
}

$logCount = 0;
$logRes = $conn->query("SELECT COUNT(*) as cnt FROM deadline_reminder_logs");
if ($logRes) {
    $row = $logRes->fetch_assoc();
    $logCount = (int)$row['cnt'];
}

// Get recent tokens
$recentTokens = [];
$recentRes = $conn->query("
    SELECT ft.id, ft.user_id, ft.updated_at, u.email, u.name
    FROM fcm_tokens ft
    LEFT JOIN users u ON u.id = ft.user_id
    ORDER BY ft.updated_at DESC
    LIMIT 10
");
if ($recentRes) {
    while ($row = $recentRes->fetch_assoc()) {
        $recentTokens[] = $row;
    }
}

// Get recent logs
$recentLogs = [];
$logsRes = $conn->query("
    SELECT drl.*, d.title
    FROM deadline_reminder_logs drl
    LEFT JOIN deadlines d ON d.id = drl.deadline_id
    ORDER BY drl.sent_at DESC
    LIMIT 10
");
if ($logsRes) {
    while ($row = $logsRes->fetch_assoc()) {
        $recentLogs[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Push Notifications Admin - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
    --bg: #f4f6f8;
    --surface: #ffffff;
    --text: #1e2228;
    --muted: #5d6674;
    --brand: #cfa430;
    --ink: #101216;
    --line: #e6e9ef;
    --success: #2f7a46;
    --danger: #d94d4d;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: "Sora", sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
}
.topbar {
    background: var(--surface);
    border-bottom: 1px solid var(--line);
    padding: 16px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.logo {
    font-weight: 700;
    font-size: 20px;
    color: var(--ink);
}
.container {
    max-width: 1200px;
    margin: 24px auto;
    padding: 0 16px;
}
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 20px;
}
.card h3 {
    font-size: 14px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 8px;
}
.card .value {
    font-size: 32px;
    font-weight: 700;
    color: var(--ink);
}
.actions {
    display: flex;
    gap: 8px;
    margin-bottom: 24px;
}
.btn {
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
    font-size: 14px;
}
.btn-primary {
    background: var(--brand);
    color: #1f180a;
}
.btn-primary:hover {
    background: #b8932a;
}
.btn-secondary {
    background: var(--surface);
    border: 1px solid var(--line);
    color: var(--text);
}
.btn-secondary:hover {
    border-color: var(--brand);
}
.table-card {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    overflow: hidden;
    margin-bottom: 24px;
}
.table-card h2 {
    font-size: 18px;
    padding: 16px;
    border-bottom: 1px solid var(--line);
}
table {
    width: 100%;
    border-collapse: collapse;
}
th {
    background: #f9fafb;
    padding: 12px 16px;
    text-align: left;
    font-weight: 600;
    font-size: 12px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    border-bottom: 1px solid var(--line);
}
td {
    padding: 12px 16px;
    border-bottom: 1px solid var(--line);
    font-size: 14px;
}
tr:last-child td {
    border-bottom: none;
}
.badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
}
.badge-success {
    background: #e7f7ec;
    color: var(--success);
}
.badge-warning {
    background: #fff5db;
    color: #8f6510;
}
.result {
    background: var(--surface);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 16px;
    margin-bottom: 24px;
    font-family: monospace;
    font-size: 12px;
    max-height: 300px;
    overflow-y: auto;
}
.result pre {
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
}
.empty {
    text-align: center;
    padding: 24px;
    color: var(--muted);
}
</style>
</head>
<body>

<header class="topbar">
    <div class="logo">Classbuzz - Push Notifications Admin</div>
    <a href="dashboard.php" style="color: var(--muted); text-decoration: none;">← Back to Dashboard</a>
</header>

<div class="container">
    <h1 style="margin-bottom: 24px;">Push Notifications Management</h1>

    <div class="grid">
        <div class="card">
            <h3>Registered Devices</h3>
            <div class="value"><?php echo $tokenCount; ?></div>
        </div>
        <div class="card">
            <h3>Reminder Logs</h3>
            <div class="value"><?php echo $logCount; ?></div>
        </div>
    </div>

    <div class="actions">
        <a href="?action=test_push" class="btn btn-primary">Send Test Notification</a>
        <a href="?action=check_reminders" class="btn btn-secondary">Check Reminders Now</a>
        <a href="../api/diagnose_push.php" class="btn btn-secondary" target="_blank">Run Diagnostics</a>
    </div>

    <?php if ($result): ?>
        <div class="result">
            <strong>Result:</strong>
            <pre><?php echo json_encode($result, JSON_PRETTY_PRINT); ?></pre>
        </div>
    <?php endif; ?>

    <div class="table-card">
        <h2>Recent Registered Devices</h2>
        <?php if (count($recentTokens) === 0): ?>
            <div class="empty">No devices registered yet.</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Email</th>
                        <th>Token Preview</th>
                        <th>Last Updated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTokens as $token): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($token['name'] ?? 'Unknown'); ?></td>
                            <td><?php echo htmlspecialchars($token['email'] ?? 'N/A'); ?></td>
                            <td><code style="font-size: 11px;"><?php echo substr($token['token'] ?? '', 0, 30); ?>...</code></td>
                            <td><?php echo htmlspecialchars($token['updated_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="table-card">
        <h2>Recent Reminder Logs</h2>
        <?php if (count($recentLogs) === 0): ?>
            <div class="empty">No reminder logs yet.</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Deadline</th>
                        <th>Reminder Type</th>
                        <th>Sent</th>
                        <th>Failed</th>
                        <th>Sent At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentLogs as $log): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($log['title'] ?? 'Unknown'); ?></td>
                            <td><span class="badge badge-warning"><?php echo htmlspecialchars($log['reminder_type']); ?></span></td>
                            <td><span class="badge badge-success"><?php echo (int)$log['sent_count']; ?></span></td>
                            <td><?php echo (int)$log['failed_count']; ?></td>
                            <td><?php echo htmlspecialchars($log['sent_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
