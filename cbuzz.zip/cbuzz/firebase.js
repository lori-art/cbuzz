import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getMessaging, getToken, onMessage } 
from "https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging.js";

const firebaseConfig = {
  apiKey: "AIzaSyCPhUXosh6YAmufvin64W2P9FC4ll46Psk",
  authDomain: "capstone-e841f.firebaseapp.com",
  projectId: "capstone-e841f",
  messagingSenderId: "358000455074",
  appId: "1:358000455074:web:23683661492484109a96fb",
};

const app = initializeApp(firebaseConfig);
const messaging = getMessaging(app);
let swRegistration = null;

function ensurePushUi() {
  if (document.getElementById("push-ui-root")) return;

  const style = document.createElement("style");
  style.id = "push-ui-style";
  style.textContent = `
    #push-ui-root {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 9999;
      width: min(320px, calc(100vw - 24px));
      display: grid;
      gap: 10px;
      pointer-events: none;
      font-family: "Sora", system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
    }
    .push-status {
      justify-self: end;
      pointer-events: auto;
      border: 1px solid #d8e3f2;
      background: rgba(255, 255, 255, 0.95);
      color: #3a4454;
      border-radius: 999px;
      padding: 7px 11px;
      font-size: 12px;
      font-weight: 700;
      box-shadow: 0 8px 20px rgba(26, 38, 54, 0.10);
    }
    .push-status.ok { border-color: #c5e8cf; color: #2f7a46; background: #f3fbf5; }
    .push-status.warn { border-color: #f2d29a; color: #8f5e12; background: #fff8ea; }
    .push-status.error { border-color: #f3c3c3; color: #a63a3a; background: #fff2f2; }
    .push-toast-list {
      display: grid;
      gap: 8px;
    }
    .push-toast {
      pointer-events: auto;
      border: 1px solid #d8e3f2;
      background: rgba(255, 255, 255, 0.98);
      border-radius: 12px;
      padding: 10px 11px;
      box-shadow: 0 10px 24px rgba(23, 33, 46, 0.14);
      transform: translateY(6px);
      opacity: 0;
      transition: transform .18s ease, opacity .18s ease;
    }
    .push-toast.show { transform: translateY(0); opacity: 1; }
    .push-toast-title { font-size: 13px; font-weight: 800; color: #1d2430; margin-bottom: 3px; }
    .push-toast-body { font-size: 12px; color: #4e5968; line-height: 1.35; }
    .push-toast.ok { border-color: #c5e8cf; background: #f6fcf8; }
    .push-toast.warn { border-color: #f2d29a; background: #fffaf0; }
    .push-toast.error { border-color: #f3c3c3; background: #fff5f5; }
  `;
  document.head.appendChild(style);

  const root = document.createElement("div");
  root.id = "push-ui-root";
  root.innerHTML = `
    <div id="pushStatus" class="push-status">Push: Initializing</div>
    <div id="pushToastList" class="push-toast-list"></div>
  `;
  document.body.appendChild(root);
}

function setPushStatus(text, level = "warn") {
  const el = document.getElementById("pushStatus");
  if (!el) return;
  el.textContent = text;
  el.className = `push-status ${level}`;
}

function showPushToast(title, body, level = "warn", timeoutMs = 4200) {
  const list = document.getElementById("pushToastList");
  if (!list) return;

  const toast = document.createElement("article");
  toast.className = `push-toast ${level}`;
  toast.innerHTML = `
    <div class="push-toast-title">${title}</div>
    <div class="push-toast-body">${body}</div>
  `;
  list.prepend(toast);
  requestAnimationFrame(() => toast.classList.add("show"));

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 220);
  }, timeoutMs);
}

async function registerPush() {
  ensurePushUi();
  try {
    if (!("serviceWorker" in navigator)) {
      console.warn("Service workers are not supported in this browser.");
      setPushStatus("Push: Not supported", "error");
      showPushToast("Push Not Supported", "This browser does not support service workers.", "error");
      return;
    }

    if (!("Notification" in window)) {
      console.warn("Notification API is not supported in this browser.");
      setPushStatus("Push: Not supported", "error");
      showPushToast("Push Not Supported", "Notification API is unavailable in this browser.", "error");
      return;
    }

    console.log("Requesting notification permission...");
    const permission = await Notification.requestPermission();
    console.log("Notification permission result:", permission);
    
    if (permission !== "granted") {
      console.warn("Notification permission was not granted.");
      setPushStatus("Push: Permission denied", "error");
      showPushToast("Notifications Blocked", "Enable notifications in your browser settings.", "warn");
      return;
    }

    console.log("Registering service worker at /cbuzz/firebase-messaging-sw.js");
    const registration = await navigator.serviceWorker.register("/cbuzz/firebase-messaging-sw.js", {
      scope: "/cbuzz/"
    });
    console.log("Service worker registered successfully:", registration);
    swRegistration = registration;
    
    console.log("Getting FCM token with VAPID key...");
    const currentToken = await getToken(messaging, {
      vapidKey: "BHZeLXp1aHckVGgScdglYiSfSAzHCGIqlxs-CXQB3WNRrmFndlakOhZkJu5JRghV_RFMj97N1pt4fpz_OAjozkg",
      serviceWorkerRegistration: registration
    });

    if (!currentToken) {
      console.warn("No FCM token received.");
      setPushStatus("Push: No token", "error");
      showPushToast("Token Missing", "No FCM token was generated for this browser.", "error");
      return;
    }

    console.log("FCM token obtained:", currentToken.substring(0, 20) + "...");
    
    console.log("Saving token to backend...");
    const response = await fetch("/cbuzz/api/save_token.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      credentials: "same-origin",
      body: new URLSearchParams({ token: currentToken })
    });

    const text = await response.text();
    console.log("Save token response status:", response.status, "body:", text);
    
    if (!response.ok || text.trim() !== "ok") {
      console.error("Failed to save FCM token:", text);
      setPushStatus("Push: Save failed", "error");
      showPushToast("Token Save Failed", text || "Could not save FCM token.", "error", 6200);
    } else {
      console.log("FCM token saved successfully.");
      setPushStatus("Push: Connected", "ok");
      showPushToast("Push Enabled", "Your device is now ready to receive reminders.", "ok");
    }
  } catch (error) {
    console.error("Push setup failed:", error);
    setPushStatus("Push: Setup failed", "error");
    showPushToast("Push Setup Failed", error?.message || "Unexpected error while setting up push.", "error", 6200);
  }
}

registerPush();

onMessage(messaging, (payload) => {
  const title = payload?.notification?.title || "Classbuzz";
  const body = payload?.notification?.body || "You have a new notification.";
  showPushToast(title, body, "ok", 6500);

  if (swRegistration) {
    swRegistration.showNotification(title, {
      body,
      icon: "/cbuzz/images/classbuzz-logo.svg"
    });
    return;
  }

  if ("Notification" in window && Notification.permission === "granted") {
    new Notification(title, { body });
    return;
  }

  alert(title + "\n" + body);
});
