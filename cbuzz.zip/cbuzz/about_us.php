<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg: #f4f6f8;
        --surface: #ffffff;
        --text: #1e2228;
        --muted: #5d6674;
        --brand: #cfa430;
        --brand-deep: #9f7d1d;
        --ink: #101216;
        --line: #e6e9ef;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: "Sora", sans-serif;
        background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
        color: var(--text);
        line-height: 1.6;
    }

    a {
        text-decoration: none;
    }

    nav {
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 40px;
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--line);
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--ink);
        font-weight: 700;
        font-size: 22px;
    }

    .logo img {
        width: 34px;
        height: 34px;
    }

    nav ul {
        list-style: none;
        display: flex;
        gap: 20px;
        align-items: center;
    }

    nav ul a {
        color: var(--ink);
        font-weight: 500;
        transition: color 0.2s ease;
    }

    nav ul a:hover {
        color: var(--brand-deep);
    }

    .nav-cta {
        background: var(--ink);
        color: #fff;
        padding: 10px 16px;
        border-radius: 999px;
    }

    .nav-cta:hover {
        color: #fff;
        background: #1b1e24;
    }

    .hero {
        max-width: 1180px;
        margin: 34px auto 24px;
        padding: 0 24px;
        display: grid;
        grid-template-columns: 1.15fr 0.85fr;
        gap: 26px;
    }

    .hero-copy {
        background: linear-gradient(120deg, #171a20 0%, #232834 100%);
        color: #fff;
        border-radius: 22px;
        padding: 42px;
        box-shadow: 0 16px 40px rgba(16, 18, 22, 0.18);
    }

    .eyebrow {
        color: #f0d184;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        font-size: 12px;
        font-weight: 700;
    }

    .hero h1 {
        margin-top: 10px;
        font-family: "Source Serif 4", serif;
        font-size: clamp(2rem, 3vw, 3rem);
        line-height: 1.1;
    }

    .hero p {
        margin-top: 16px;
        color: #cdd3df;
        max-width: 60ch;
    }

    .hero-actions {
        margin-top: 26px;
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .btn {
        padding: 12px 18px;
        border-radius: 10px;
        font-weight: 600;
        display: inline-block;
    }

    .btn-primary {
        background: var(--brand);
        color: #18120a;
    }

    .btn-secondary {
        border: 1px solid #41495a;
        color: #f3f5f9;
    }

    .hero-stat {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 22px;
        padding: 28px;
        display: grid;
        gap: 16px;
        align-content: center;
    }

    .metric-row {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        padding-bottom: 14px;
        border-bottom: 1px dashed #d9dde5;
    }

    .metric-row:last-child {
        border-bottom: none;
        padding-bottom: 0;
    }

    .metric-row strong {
        font-size: 34px;
        color: var(--ink);
    }

    .content {
        max-width: 1180px;
        margin: 0 auto;
        padding: 14px 24px 62px;
    }

    .section-title {
        font-family: "Source Serif 4", serif;
        font-size: clamp(1.6rem, 2vw, 2.2rem);
        margin-bottom: 8px;
    }

    .section-sub {
        color: var(--muted);
        margin-bottom: 24px;
    }

    .values-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 34px;
    }

    .value-card {
        background: var(--surface);
        border: 2px solid transparent;
        border-radius: 14px;
        padding: 18px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .value-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #cfa430, #9f7d1d);
    }

    .value-card:nth-child(1) {
        border-color: #e8f4f8;
        background: linear-gradient(135deg, #f8fcff 0%, #f0f8fc 100%);
    }

    .value-card:nth-child(1)::before {
        background: linear-gradient(90deg, #0288d1, #01579b);
    }

    .value-card:nth-child(2) {
        border-color: #f0e8f8;
        background: linear-gradient(135deg, #faf8ff 0%, #f5f0ff 100%);
    }

    .value-card:nth-child(2)::before {
        background: linear-gradient(90deg, #7b1fa2, #4a148c);
    }

    .value-card:nth-child(3) {
        border-color: #e8f8f0;
        background: linear-gradient(135deg, #f0fff8 0%, #e0f7f4 100%);
    }

    .value-card:nth-child(3)::before {
        background: linear-gradient(90deg, #00796b, #004d40);
    }

    .value-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(17, 22, 31, 0.1);
    }

    .value-card h3 {
        margin-bottom: 8px;
        color: var(--ink);
        font-size: 17px;
    }

    .value-card p {
        color: var(--muted);
        font-size: 14px;
    }

    .team-wrap {
        background: linear-gradient(180deg, #fff 0%, #f7f9fc 100%);
        border: 1px solid var(--line);
        border-radius: 20px;
        padding: 24px;
    }

    .team-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
    }

    .member-card {
        background: #fff;
        border: 1px solid #e7ebf2;
        border-radius: 14px;
        padding: 16px;
        text-align: center;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        overflow: hidden;
    }

    .member-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(17, 22, 31, 0.08);
    }

    .member-image {
        width: 100%;
        height: 140px;
        border-radius: 10px;
        margin-bottom: 12px;
        object-fit: cover;
        background: linear-gradient(135deg, #f0f0f0 0%, #e0e0e0 100%);
    }

    .avatar {
        width: 84px;
        height: 84px;
        border-radius: 50%;
        margin: 0 auto 10px;
        border: 3px solid #f2f4f8;
        display: grid;
        place-items: center;
        font-weight: 700;
        font-size: 24px;
        color: #fff;
        background: linear-gradient(135deg, #303745 0%, #56627a 100%);
    }

    .member-card h3 {
        font-size: 16px;
        color: var(--ink);
    }

    .member-card p {
        color: var(--muted);
        font-size: 13px;
        margin-top: 4px;
    }

    .cta {
        margin-top: 26px;
        background: linear-gradient(95deg, #12151b 0%, #222837 100%);
        border-radius: 18px;
        color: #f4f6fb;
        padding: 24px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
    }

    .cta p {
        color: #c4cbda;
    }

    footer {
        text-align: center;
        padding: 22px;
        color: #6c7482;
        font-size: 14px;
    }

    @media (max-width: 1024px) {
        .hero {
            grid-template-columns: 1fr;
        }

        .values-grid {
            grid-template-columns: 1fr 1fr;
        }

        .team-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 760px) {
        nav {
            padding: 14px 16px;
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }

        nav ul {
            gap: 14px;
            flex-wrap: wrap;
        }

        .hero,
        .content {
            padding-left: 16px;
            padding-right: 16px;
        }

        .hero-copy {
            padding: 26px 20px;
        }

        .values-grid,
        .team-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<nav>
    <a class="logo" href="index.php">
        <img src="images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about_us.php">About Us</a></li>
        <li><a class="nav-cta" href="auth/login.php">Login</a></li>
    </ul>
</nav>

<section class="hero">
    <div class="hero-copy">
        <div class="eyebrow">Student-first platform</div>
        <h1>We Built Classbuzz To Make Deadlines Less Stressful</h1>
        <p>Classbuzz helps students, teachers, and organizations stay aligned through smart reminders, easy task tracking, and clear progress visibility. Our focus is convenience without complexity.</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="auth/register.php">Join Classbuzz</a>
            <a class="btn btn-secondary" href="#team">Meet the Team</a>
        </div>
    </div>
    <aside class="hero-stat">
        <div class="metric-row">
            <span>Active learners</span>
            <strong>2,000+</strong>
        </div>
        <div class="metric-row">
            <span>Tasks tracked monthly</span>
            <strong>15k+</strong>
        </div>
        <div class="metric-row">
            <span>On-time submissions</span>
            <strong>94%</strong>
        </div>
    </aside>
</section>

<main class="content">
    <h2 class="section-title">What Makes Us Different</h2>
    <p class="section-sub">We balance modern design with practical tools that students can use every day without a learning curve.</p>

    <section class="values-grid">
        <article class="value-card">
            <h3>Clear Task Visibility</h3>
            <p>Every assignment, exam, and reminder is organized in one view to reduce missed deadlines.</p>
        </article>
        <article class="value-card">
            <h3>Fast, Convenient Workflow</h3>
            <p>Simple actions and straightforward screens help users focus on results instead of figuring out controls.</p>
        </article>
        <article class="value-card">
            <h3>Built For Consistency</h3>
            <p>Reliable alerts and progress tracking help students develop strong habits and better time management.</p>
        </article>
    </section>

    <section class="team-wrap" id="team">
        <h2 class="section-title">Our Team</h2>
        <p class="section-sub">A multidisciplinary group committed to creating smarter student tools.</p>

        <div class="team-grid">
            <div class="member-card">
                <div class="avatar" aria-hidden="true">JD</div>
                <h3>John Doe</h3>
                <p>Frontend Developer</p>
            </div>
            <div class="member-card" src="images/" alt="Emily Johnson">
                <div class="avatar" aria-hidden="true">JS</div>
                <h3>Jane Smith</h3>
                <p>Backend Developer</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">EJ</div>
                <h3>Emily Johnson</h3>
                <p>UI/UX Designer</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">MB</div>
                <h3>Michael Brown</h3>
                <p>Fullstack Developer</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">SL</div>
                <h3>Sarah Lee</h3>
                <p>Project Manager</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">DK</div>
                <h3>David Kim</h3>
                <p>Mobile Developer</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">LM</div>
                <h3>Laura Martinez</h3>
                <p>Quality Assurance</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">JW</div>
                <h3>James Wilson</h3>
                <p>Database Administrator</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">AC</div>
                <h3>Amanda Chen</h3>
                <p>DevOps Engineer</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">RG</div>
                <h3>Robert Garcia</h3>
                <p>Security Specialist</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">NP</div>
                <h3>Nina Patel</h3>
                <p>Product Manager</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">CT</div>
                <h3>Christopher Taylor</h3>
                <p>Technical Lead</p>
            </div>
            <div class="member-card">
                <div class="avatar" aria-hidden="true">VR</div>
                <h3>Victoria Rodriguez</h3>
                <p>Community Manager</p>
            </div>
        </div>

        <div class="cta">
            <div>
                <h3>Ready to make schoolwork easier?</h3>
                <p>Create an account and start organizing your deadlines with Classbuzz.</p>
            </div>
            <a class="btn btn-primary" href="auth/register.php">Get Started</a>
        </div>
    </section>
</main>

<footer>
    &copy; 2026 Classbuzz. All rights reserved.
</footer>

</body>
</html>
