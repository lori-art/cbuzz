<?php
include "../config/db.php";

$message = "";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    // Note: Using password_hash is more secure than MD5
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Using prepared statements to prevent SQL Injection
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'student')");
    $stmt->bind_param("sss", $name, $email, $password);
    
    if ($stmt->execute()) {
        $message = "Registration successful!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Classbuzz</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-yellow: #E8B931;
            --dark-bg: #1A1A1A;
            --text-main: #333333;
            --text-muted: #666666;
            --white: #FFFFFF;
            --bg-light: #F9F9F9;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: var(--white);
            color: var(--text-main);
            line-height: 1.6;
        }

        /* Navbar */
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 8%;
            background: var(--white);
        }

        .logo {
            display: flex;
            align-items: center;
            font-weight: 700;
            font-size: 1.5rem;
            gap: 10px;
        }

        .logo-icon {
            background: #000;
            color: var(--primary-yellow);
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-main);
            font-weight: 500;
        }

        .login-btn {
            background: #111;
            color: white !important;
            padding: 10px 25px;
            border-radius: 50px;
        }

        /* Hero Section */
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1.2fr 0.8fr;
            gap: 30px;
            align-items: start;
        }

        .hero-card {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=1000&q=80');
            background-size: cover;
            background-position: center;
            border-radius: 24px;
            padding: 60px;
            color: white;
            min-height: 450px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .tagline {
            color: var(--primary-yellow);
            text-transform: uppercase;
            letter-spacing: 2px;
            font-weight: 700;
            font-size: 0.8rem;
            margin-bottom: 20px;
        }

        h1 {
            font-family: 'Playfair Display', serif;
            font-size: 3.5rem;
            line-height: 1.1;
            margin-bottom: 25px;
        }

        .hero-desc {
            font-size: 1.1rem;
            color: rgba(255,255,255,0.8);
            margin-bottom: 40px;
            max-width: 500px;
        }

        .hero-btns {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 14px 28px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: 0.3s;
            border: none;
            font-size: 1rem;
        }

        .btn-yellow {
            background: var(--primary-yellow);
            color: #000;
        }

        .btn-outline {
            background: transparent;
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
        }

        /* Form Card */
        .register-card {
            background: var(--white);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            border: 1px solid #eee;
        }

        .register-card h2 {
            margin-bottom: 25px;
            font-size: 1.8rem;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-muted);
        }

        input {
            width: 100%;
            padding: 14px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            outline: none;
            transition: 0.3s;
        }

        input:focus {
            border-color: var(--primary-yellow);
            box-shadow: 0 0 0 3px rgba(232, 185, 49, 0.1);
        }

        .submit-btn {
            width: 100%;
            background: #111;
            color: white;
            padding: 16px;
            border-radius: 8px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            background: #e7f5ff;
            color: #0056b3;
            font-weight: 500;
        }

        /* Stats Section */
        .stats-section {
            margin-top: 60px;
            padding: 0 8%;
        }

        .stats-section h3 {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .stats-section p {
            color: var(--text-muted);
            margin-bottom: 40px;
        }

        @media (max-width: 992px) {
            .container {
                grid-template-columns: 1fr;
            }
            h1 {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>

    <nav>
        <div class="logo">
            <div class="logo-icon"></div>
            Classbuzz
        </div>
        <div class="nav-links">
            <a href="login.php" class="login-btn">Login</a>
        </div>
    </nav>

    <div class="container">
        <!-- Left Side: Hero Design -->
        <div class="hero-card">
            <div class="tagline">Student-First Platform</div>
            <h1>Stay On Top Of Deadlines Without The Stress</h1>
            <p class="hero-desc">Classbuzz helps students organize schoolwork, track tasks clearly, and get reminders that keep submissions on time.</p>
            <div class="hero-btns">
                <a href="#" class="btn btn-yellow">Get Started</a>
                <a href="#" class="btn btn-outline">View Features</a>
            </div>
        </div>

        <!-- Right Side: Registration Form -->
        <div class="register-card">
            <h2>Create Account</h2>
            
            <?php if($message): ?>
                <div class="alert"><?php echo $message; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Full Name</label>
                    <input name="name" placeholder="John Doe" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="john@example.com" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="••••••••" required>
                </div>
                <button type="submit" class="submit-btn">Register</button>
            </form>
        </div>
    </div>

    <div class="stats-section">
        <h3>Core Features</h3>
        <p>Built to be clean, easy, and useful in your everyday school workflow.</p>
    </div>

</body>
</html>
Manus