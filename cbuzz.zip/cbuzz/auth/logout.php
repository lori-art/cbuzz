<?php
session_start();

// Destroy all session data
session_unset();
session_destroy();

// Redirect user to login page
header("Location: ../auth/login.php");
exit;
?>