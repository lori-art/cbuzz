<?php
session_start();
include "../config/db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit;
}

$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$desc = isset($_POST['description']) ? trim($_POST['description']) : '';
$deadline = isset($_POST['deadline']) ? trim($_POST['deadline']) : '';

if ($title === '' || $deadline === '') {
    $_SESSION['flash_error'] = "Title and deadline are required.";
    header("Location: dashboard.php");
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO deadlines (title, description, deadline_datetime)
    VALUES (?, ?, ?)
");
$stmt->bind_param("sss", $title, $desc, $deadline);
$ok = $stmt->execute();

if (!$ok) {
    $_SESSION['flash_error'] = "Failed to add deadline. Please try again.";
    header("Location: dashboard.php");
    exit;
}

// Send email immediately
include "../api/send_email.php";

$_SESSION['flash_success'] = "Deadline added successfully.";
header("Location: dashboard.php");
exit;
?>
