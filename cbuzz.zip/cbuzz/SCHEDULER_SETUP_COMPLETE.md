# Complete Scheduler Setup Guide

## Choose Your Operating System

### 🪟 Windows Users
Follow: **WINDOWS_TASK_SCHEDULER_GUIDE.md**
- Time: 10 minutes
- Difficulty: Easy
- No command line needed

### 🍎 Mac Users
Follow: **LINUX_MAC_CRON_GUIDE.md**
- Time: 5 minutes
- Difficulty: Easy
- Uses Terminal

### 🐧 Linux Users
Follow: **LINUX_MAC_CRON_GUIDE.md**
- Time: 5 minutes
- Difficulty: Easy
- Uses Terminal

---

## Quick Summary

### What You're Setting Up
A scheduler that automatically checks for upcoming deadlines every 5 minutes and sends push notifications.

### What Gets Installed
- **Windows:** Task in Task Scheduler
- **Linux/Mac:** Cron job in crontab

### What It Does
Every 5 minutes:
1. Checks all deadlines in database
2. Finds deadlines within reminder windows (24h, 12h, 1h, 30m)
3. Sends push notifications to all registered devices
4. Logs all activity

---

## Before You Start

### Prerequisites
- [ ] XAMPP is installed and running
- [ ] Database tables created (run `http://localhost/cbuzz/api/setup_push.php`)
- [ ] At least one user has registered a device (see "Push: Connected" on dashboard)
- [ ] At least one deadline exists in the database

### Verify Prerequisites
1. Check XAMPP is running (Apache and MySQL should be green)
2. Visit `http://localhost/cbuzz/api/diagnose_push.php`
3. All items should show as true/green

---

## Step-by-Step Setup

### Step 1: Choose Your Platform

**Windows?** → Go to **WINDOWS_TASK_SCHEDULER_GUIDE.md**

**Mac or Linux?** → Go to **LINUX_MAC_CRON_GUIDE.md**

### Step 2: Follow the Guide

Follow all steps in the guide for your platform.

### Step 3: Verify It Works

After setup, verify the scheduler is running:

**Windows:**
1. Open Task Scheduler
2. Find "Classbuzz Reminder Scheduler"
3. Right-click → Run
4. Check logs: `C:\xampp\htdocs\cbuzz\logs\scheduler.log`

**Linux/Mac:**
1. Open Terminal
2. Run: `tail -f /var/www/html/cbuzz/logs/scheduler.log`
3. Wait 5 minutes
4. Should see execution logs

### Step 4: Test with a Deadline

1. Log in to admin: `http://localhost/cbuzz/admin/dashboard.php`
2. Create deadline for 35 minutes from now
3. Wait 5 minutes
4. Check logs - should see reminder being sent
5. Check device for notification

---

## Verification Checklist

After setup, verify everything:

- [ ] Scheduler is installed (Task Scheduler or crontab)
- [ ] Scheduler runs successfully (check logs)
- [ ] Created test deadline
- [ ] Received notification after 5 minutes
- [ ] Admin panel shows recent reminders
- [ ] Logs show regular execution

---

## Troubleshooting

### Scheduler doesn't run

**Windows:**
1. Open Task Scheduler
2. Right-click task → Properties
3. General tab → Check "Run whether user is logged in or not"
4. Click OK

**Linux/Mac:**
1. Check cron service: `sudo service cron status`
2. Verify cron job: `crontab -l`
3. Check logs: `tail -f /var/www/html/cbuzz/logs/scheduler.log`

### Scheduler runs but nothing happens

1. Check logs: `logs/scheduler.log`
2. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
3. Verify database has deadlines
4. Verify devices are registered

### No notifications received

1. Check if device is registered (see "Push: Connected")
2. Check if deadline is within reminder window
3. Check logs for errors
4. Run diagnostics

---

## Monitoring

### Check Logs

**Windows:**
```
C:\xampp\htdocs\cbuzz\logs\scheduler.log
```

**Linux/Mac:**
```bash
tail -f /var/www/html/cbuzz/logs/scheduler.log
```

### Admin Panel

Visit: `http://localhost/cbuzz/admin/scheduler.php`

See:
- Statistics (deadlines, devices, reminders)
- Recent reminders sent
- Scheduler logs
- Upcoming deadlines

### Manual Test

**Windows:**
```cmd
C:\xampp\php\php.exe C:\xampp\htdocs\cbuzz\api\scheduler.php
```

**Linux/Mac:**
```bash
/usr/bin/php /var/www/html/cbuzz/api/scheduler.php
```

---

## Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| Task doesn't run | Check "Run whether user is logged in" (Windows) or cron service (Linux/Mac) |
| Nothing happens | Check logs, verify database has deadlines |
| No notifications | Verify device is registered, check reminder window |
| Permission denied | Make script executable: `chmod +x scheduler.php` |
| PHP not found | Verify PHP path, update in Task Scheduler or crontab |

---

## Reminder Schedule

The scheduler sends reminders at these times:

| Reminder | Time Before Deadline |
|----------|---------------------|
| 1st | 24 hours |
| 2nd | 12 hours |
| 3rd | 1 hour |
| 4th | 30 minutes |

Each reminder is sent only once per deadline.

---

## Next Steps

1. ✅ Choose your platform (Windows, Mac, or Linux)
2. ✅ Follow the setup guide for your platform
3. ✅ Verify scheduler is running
4. ✅ Create test deadline
5. ✅ Receive automatic notification
6. ✅ Monitor logs regularly

---

## Support Resources

| Resource | Purpose |
|----------|---------|
| `WINDOWS_TASK_SCHEDULER_GUIDE.md` | Windows setup guide |
| `LINUX_MAC_CRON_GUIDE.md` | Linux/Mac setup guide |
| `SCHEDULER_INSTALLATION.md` | Detailed installation guide |
| `http://localhost/cbuzz/admin/scheduler.php` | Admin panel |
| `http://localhost/cbuzz/api/diagnose_push.php` | System diagnostics |

---

## Quick Links

| Task | URL |
|------|-----|
| Setup Database | `http://localhost/cbuzz/api/setup_push.php` |
| Run Diagnostics | `http://localhost/cbuzz/api/diagnose_push.php` |
| Admin Panel | `http://localhost/cbuzz/admin/scheduler.php` |
| Student Dashboard | `http://localhost/cbuzz/student/dashboard.php` |

---

## Success Indicators

You'll know it's working when:

✅ Scheduler runs every 5 minutes (check logs)
✅ Reminders are triggered for upcoming deadlines
✅ Notifications appear on your device
✅ Admin panel shows recent reminders
✅ No errors in logs

---

## Estimated Time

- **Windows:** 10 minutes
- **Linux/Mac:** 5 minutes
- **Testing:** 10 minutes
- **Total:** 15-20 minutes

---

## Questions?

1. Check the setup guide for your platform
2. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
3. Check logs: `logs/scheduler.log`
4. Visit admin panel: `http://localhost/cbuzz/admin/scheduler.php`

---

**You're ready to set up automatic push notifications!** 🎉

Choose your platform and follow the guide.
