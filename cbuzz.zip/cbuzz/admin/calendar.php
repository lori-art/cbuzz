<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
include "../config/db.php";

$adminName = isset($_SESSION['user']['name']) && $_SESSION['user']['name'] !== ''
    ? $_SESSION['user']['name']
    : 'Admin';

$hour = (int)date('H');
$greeting = 'Hello';
if ($hour < 12) {
    $greeting = 'Good morning';
} elseif ($hour < 18) {
    $greeting = 'Good afternoon';
} else {
    $greeting = 'Good evening';
}

$view = isset($_GET['view']) ? $_GET['view'] : 'all';
$allowedViews = ['all', 'upcoming', 'completed', 'past_due', 'new'];
if (!in_array($view, $allowedViews, true)) {
    $view = 'all';
}

$hasCompletionTable = false;
$tableCheck = $conn->query("SHOW TABLES LIKE 'deadline_completions'");
if ($tableCheck && $tableCheck->num_rows > 0) {
    $hasCompletionTable = true;
}

if ($hasCompletionTable) {
    $query = "
        SELECT
            d.id,
            d.title,
            d.description,
            d.deadline_datetime,
            COALESCE(c.completed_users, 0) AS completed_users
        FROM deadlines d
        LEFT JOIN (
            SELECT deadline_id, COUNT(*) AS completed_users
            FROM deadline_completions
            GROUP BY deadline_id
        ) c ON c.deadline_id = d.id
        ORDER BY d.deadline_datetime ASC
    ";
} else {
    $query = "
        SELECT
            d.id,
            d.title,
            d.description,
            d.deadline_datetime,
            0 AS completed_users
        FROM deadlines d
        ORDER BY d.deadline_datetime ASC
    ";
}

$res = $conn->query($query);
$allDeadlines = [];
$counts = [
    'all' => 0,
    'upcoming' => 0,
    'completed' => 0,
    'past_due' => 0,
    'new' => 0
];

$nowTs = time();
while ($res && $row = $res->fetch_assoc()) {
    $deadlineTs = strtotime($row['deadline_datetime']);
    if ((int)$row['completed_users'] > 0) {
        $state = 'completed';
    } elseif ($deadlineTs !== false && $deadlineTs < $nowTs) {
        $state = 'past_due';
    } else {
        $state = 'upcoming';
    }

    $row['state'] = $state;
    $allDeadlines[] = $row;
    $counts['all']++;
    $counts[$state]++;
}

$subjects = ['PEH 300', 'ICT LECTURE', 'ICT 400', 'PILOSOPHY', 'RESEARCH', 'ENTREPRENEUR', 'IMMERSION'];
$subjectFilter = isset($_GET['subject']) ? trim($_GET['subject']) : 'all';
if ($subjectFilter !== 'all' && !in_array($subjectFilter, $subjects, true) && $subjectFilter !== 'Other') {
    $subjectFilter = 'all';
}

$viewFilteredDeadlines = [];
foreach ($allDeadlines as $deadline) {
    if ($view === 'all' || $deadline['state'] === $view) {
        $viewFilteredDeadlines[] = $deadline;
    }
}

$subjectCounts = [];
foreach ($subjects as $subject) {
    $subjectCounts[$subject] = 0;
}
$subjectCounts['Other'] = 0;
foreach ($allDeadlines as $deadline) {
    $subject = isset($deadline['title']) ? trim($deadline['title']) : '';
    if (isset($subjectCounts[$subject])) {
        $subjectCounts[$subject]++;
    } else {
        $subjectCounts['Other']++;
    }
}

$newDeadlineIds = [];
$newRes = $conn->query("SELECT id FROM deadlines ORDER BY id DESC LIMIT 8");
if ($newRes) {
    while ($newRow = $newRes->fetch_assoc()) {
        $newDeadlineIds[] = (int)$newRow['id'];
    }
}
$counts['new'] = count($newDeadlineIds);

$filteredDeadlines = [];
foreach ($allDeadlines as $deadline) {
    $taskSubject = isset($deadline['title']) ? trim($deadline['title']) : '';
    $normalizedTaskSubject = in_array($taskSubject, $subjects, true) ? $taskSubject : 'Other';
    $isNew = in_array((int)$deadline['id'], $newDeadlineIds, true);
    $viewMatch = ($view === 'new') ? $isNew : ($view === 'all' || $deadline['state'] === $view);
    if (($subjectFilter === 'all' || $subjectFilter === $normalizedTaskSubject) && $viewMatch) {
        $filteredDeadlines[] = $deadline;
    }
}

$calendarStatusByDate = [];
$statusPriority = ['completed' => 1, 'upcoming' => 2, 'past_due' => 3];
foreach ($allDeadlines as $deadline) {
    $taskSubject = isset($deadline['title']) ? trim($deadline['title']) : '';
    $normalizedTaskSubject = in_array($taskSubject, $subjects, true) ? $taskSubject : 'Other';
    if ($subjectFilter !== 'all' && $subjectFilter !== $normalizedTaskSubject) {
        continue;
    }

    $dateKey = substr((string)$deadline['deadline_datetime'], 0, 10);
    if ($dateKey === '') {
        continue;
    }

    $state = isset($deadline['state']) ? $deadline['state'] : 'upcoming';
    if (!isset($statusPriority[$state])) {
        continue;
    }
    if (!isset($calendarStatusByDate[$dateKey]) || $statusPriority[$state] > $statusPriority[$calendarStatusByDate[$dateKey]]) {
        $calendarStatusByDate[$dateKey] = $state;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Calendar - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
:root { --bg:#f4f6f8; --surface:#fff; --text:#1e2228; --muted:#5d6674; --line:#e6e9ef; --danger:#d94d4d; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: "Sora", sans-serif; background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg); color: var(--text); min-height: 100vh; }
a { text-decoration: none; }
.topbar { position: sticky; top: 0; z-index: 30; display: flex; justify-content: space-between; align-items: center; padding: 14px 24px; background: rgba(255,255,255,.88); backdrop-filter: blur(8px); border-bottom: 1px solid var(--line); }
.logo { display: flex; align-items: center; gap: 10px; color: #101216; font-weight: 700; font-size: 21px; }
.logo img { width: 32px; height: 32px; }
.logout-btn { border: none; background: var(--danger); color: #fff; border-radius: 999px; padding: 9px 14px; cursor: pointer; font-weight: 600; }
.topbar-right { display: flex; align-items: center; gap: 14px; }
.datetime-wrap { display: flex; align-items: baseline; gap: 12px; color: #2f3339; }
.datetime-time { font-size: 28px; font-weight: 700; line-height: 1; letter-spacing: 0.01em; }
.datetime-date { font-size: 16px; color: #666c76; font-weight: 600; line-height: 1; }
.layout { max-width: 1320px; margin: 18px auto; padding: 0 16px 24px; display: grid; grid-template-columns: 290px 1fr; gap: 18px; }
.sidebar { background: #fff; border: 1px solid var(--line); border-radius: 16px; padding: 14px; align-self: start; position: sticky; top: 78px; max-height: calc(100vh - 96px); overflow-y: auto; box-shadow: 0 10px 22px rgba(30, 38, 53, 0.06); }
.greeting { background: linear-gradient(120deg, #171a20 0%, #232834 100%); color: #fff; border-radius: 12px; padding: 12px; margin-bottom: 14px; }
.greeting strong { display: block; font-size: 16px; }
.greeting span { color: #d4d9e7; font-size: 12px; }
.side-title { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: .1em; margin: 12px 0 8px; }
.side-links { display: grid; gap: 8px; }
.side-link { border: 1px solid var(--line); border-radius: 10px; padding: 9px 10px; color: #2d3440; font-size: 14px; font-weight: 600; }
.side-link:hover, .side-link.active { border-color: #dcc57f; background: #fff9e8; }
.subject-dropdown { width: 100%; border: 1px solid var(--line); border-radius: 10px; padding: 9px 10px; font-family: inherit; font-size: 13px; color: #2d3440; background: #fff; }
.main { display: grid; gap: 14px; }
.quick-overview { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }
.overview-item { display:block; border: 1px solid var(--line); border-radius: 12px; background: #fff; padding: 10px; }
.overview-item:hover { border-color:#d8c38a; box-shadow:0 6px 16px rgba(26,33,45,.06); }
.overview-item strong { display: block; font-size: 18px; color: #1f2735; }
.overview-item span { font-size: 11px; color: var(--muted); }
.card { background: #fff; border: 1px solid var(--line); border-radius: 16px; padding: 18px; box-shadow: 0 10px 24px rgba(24, 30, 43, 0.05); }
.card h2 { font-family: "Source Serif 4", serif; font-size: 26px; margin-bottom: 4px; }
.sub { color: var(--muted); font-size: 13px; margin-bottom: 12px; }
.filter-bar { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
.filter-chip { border: 1px solid var(--line); color: #2f3743; border-radius: 999px; padding: 6px 10px; font-size: 12px; font-weight: 700; }
.filter-chip.active { border-color: #dfc776; background: #fff8e2; color: #7c5c12; }
.calendar-widget { border: 1px solid #d8e5f7; border-radius: 14px; background: #fff; overflow: hidden; }
.calendar-main .cal-day { height: 52px; font-size: 14px; }
.cal-head { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 10px; background: linear-gradient(90deg, #e9f5ff 0%, #edf3ff 100%); border-bottom: 1px solid #d8e5f7; }
.cal-left { display: flex; align-items: center; gap: 8px; }
.cal-title { font-size: 13px; font-weight: 800; color: #2b3340; min-width: 112px; text-align: center; }
.cal-nav { border: 1px solid #bfd7f2; background: #f8fcff; border-radius: 8px; width: 30px; height: 30px; cursor: pointer; }
.cal-view { display: flex; gap: 6px; align-items: center; }
.cal-pill { border: 1px solid #bcd7f7; background: #f7fbff; color: #2e76c9; border-radius: 999px; font-size: 11px; font-weight: 700; padding: 5px 10px; }
.cal-pill.active { background: #1990e6; color: #fff; border-color: #1990e6; }
.cal-today { border: 1px solid #1990e6; background: #fff; color: #1990e6; border-radius: 10px; font-size: 11px; font-weight: 800; padding: 6px 9px; cursor: pointer; }
.cal-weekdays,.cal-days { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; padding: 8px 10px 0; }
.cal-weekdays span { font-size: 10px; color: var(--muted); text-align: center; padding: 2px 0; font-weight: 700; }
.cal-day { border: 1px solid transparent; background: #fff; border-radius: 8px; height: 32px; font-size: 12px; cursor: pointer; color: #2e3745; }
.cal-day:hover { border-color: #b8d5f5; }
.cal-day.muted { color: #aab2bf; }
.cal-day.active { outline: 2px solid #2f80e7; border-color: #2f80e7; }
.cal-day.today { border-color: #cfd7e6; }
.cal-day.status-upcoming { background: #eaf3ff; border-color: #9fc1ee; color: #2c65bc; font-weight: 700; }
.cal-day.status-past_due { background: #ffecee; border-color: #edb0b5; color: #b43a3f; font-weight: 700; }
.cal-day.status-completed { background: #eaf9ef; border-color: #a8d9b6; color: #2f7c47; font-weight: 700; }
.cal-legend { display: flex; gap: 10px; padding: 8px 10px 10px; align-items: center; flex-wrap: wrap; }
.cal-legend span { font-size: 10px; color: #4f5968; display: inline-flex; align-items: center; gap: 5px; }
.dot { width: 8px; height: 8px; border-radius: 999px; display: inline-block; }
.dot-red { background: #d86060; } .dot-blue { background: #4f89d7; } .dot-green { background: #3fa464; }
.task-scroll { max-height: 34vh; overflow-y: auto; padding-right: 6px; margin-top: 10px; }
.task-item { border: 1px solid var(--line); border-left: 4px solid #d4b458; border-radius: 10px; padding: 10px; background: #fff; margin-bottom: 8px; }
.task-item[data-state="completed"] { border-left-color: #55a76a; background: #f8fcf9; }
.task-item[data-state="past_due"] { border-left-color: #d46363; background: #fff8f8; }
.task-head { display: flex; justify-content: space-between; gap: 10px; align-items: center; }
.task-title { font-size: 14px; font-weight: 700; color: #202734; }
.badge { border-radius: 999px; padding: 3px 8px; font-size: 11px; font-weight: 700; }
.badge-upcoming { color: #8e6510; background: #fff5db; border: 1px solid #f3e0a7; }
.badge-completed { color: #2b7340; background: #e7f7ec; border: 1px solid #bfe7ca; }
.badge-past { color: #9a3333; background: #ffecec; border: 1px solid #f4caca; }
.task-desc { margin-top: 5px; color: #505968; font-size: 13px; }
.task-time { margin-top: 4px; color: var(--muted); font-size: 12px; }
.empty { font-size: 13px; color: var(--muted); padding: 8px; border: 1px dashed #cfd6e3; border-radius: 10px; text-align: center; }
@media (max-width: 980px) { .layout { grid-template-columns: 1fr; } .sidebar { position: static; } .quick-overview { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (max-width: 980px) { .datetime-wrap { flex-direction: column; align-items: flex-end; gap: 2px; } .datetime-time { font-size: 22px; } .datetime-date { font-size: 13px; } }
</style>
</head>
<body>
<header class="topbar">
    <a class="logo" href="../index.php"><img src="../images/classbuzz-logo.svg" alt="Classbuzz logo"><span>Classbuzz</span></a>
    <div class="topbar-right">
        <div class="datetime-wrap" aria-live="polite">
            <span class="datetime-time" id="liveTime">--:--</span>
            <span class="datetime-date" id="liveDate">--</span>
        </div>
        <button class="logout-btn" onclick="location.href='../auth/logout.php'">Logout</button>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <div class="greeting">
            <strong><?php echo htmlspecialchars($greeting . ', ' . $adminName); ?></strong>
            <span>Administrator calendar</span>
        </div>
        <div class="side-title">Menu</div>
        <div class="side-links">
            <a class="side-link" href="dashboard.php?subject=<?php echo urlencode($subjectFilter); ?>&view=<?php echo urlencode($view); ?>">Dashboard</a>
            <a class="side-link active" href="calendar.php?subject=<?php echo urlencode($subjectFilter); ?>&view=<?php echo urlencode($view); ?>">Calendar</a>
        </div>
        <div class="side-title">Subjects</div>
        <form method="GET">
            <input type="hidden" name="view" value="<?php echo htmlspecialchars($view); ?>">
            <select class="subject-dropdown" name="subject" onchange="this.form.submit()">
                <option value="all" <?php echo $subjectFilter === 'all' ? 'selected' : ''; ?>>All Subjects (<?php echo (int)$counts['all']; ?>)</option>
                <?php foreach ($subjectCounts as $subjectName => $count): ?>
                    <option value="<?php echo htmlspecialchars($subjectName); ?>" <?php echo $subjectFilter === $subjectName ? 'selected' : ''; ?>><?php echo htmlspecialchars($subjectName); ?> (<?php echo (int)$count; ?>)</option>
                <?php endforeach; ?>
            </select>
        </form>
    </aside>

    <main class="main">
        <section class="quick-overview">
            <a class="overview-item" href="?view=upcoming&subject=<?php echo urlencode($subjectFilter); ?>"><strong><?php echo (int)$counts['upcoming']; ?></strong><span>Upcoming</span></a>
            <a class="overview-item" href="?view=completed&subject=<?php echo urlencode($subjectFilter); ?>"><strong><?php echo (int)$counts['completed']; ?></strong><span>Completed</span></a>
            <a class="overview-item" href="?view=past_due&subject=<?php echo urlencode($subjectFilter); ?>"><strong><?php echo (int)$counts['past_due']; ?></strong><span>Past Due</span></a>
            <a class="overview-item" href="?view=all&subject=all"><strong><?php echo (int)$counts['all']; ?></strong><span>All Tasks</span></a>
        </section>

        <section class="card">
            <h2>Calendar Dashboard</h2>
            <p class="sub">Click a date to filter deadlines.</p>

            <div class="filter-bar">
                <a class="filter-chip <?php echo $view === 'all' ? 'active' : ''; ?>" href="?view=all&subject=<?php echo urlencode($subjectFilter); ?>">All (<?php echo (int)$counts['all']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'upcoming' ? 'active' : ''; ?>" href="?view=upcoming&subject=<?php echo urlencode($subjectFilter); ?>">Upcoming (<?php echo (int)$counts['upcoming']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'completed' ? 'active' : ''; ?>" href="?view=completed&subject=<?php echo urlencode($subjectFilter); ?>">Completed (<?php echo (int)$counts['completed']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'past_due' ? 'active' : ''; ?>" href="?view=past_due&subject=<?php echo urlencode($subjectFilter); ?>">Past Due (<?php echo (int)$counts['past_due']; ?>)</a>
                <a class="filter-chip <?php echo $view === 'new' ? 'active' : ''; ?>" href="?view=new&subject=<?php echo urlencode($subjectFilter); ?>">New (<?php echo (int)$counts['new']; ?>)</a>
            </div>

            <div class="calendar-widget calendar-main">
                <div class="cal-head">
                    <div class="cal-left">
                        <button class="cal-nav" type="button" id="calPrev">&#8249;</button>
                        <div class="cal-title" id="calTitle"></div>
                        <button class="cal-nav" type="button" id="calNext">&#8250;</button>
                    </div>
                    <div class="cal-view">
                        <span class="cal-pill">Day</span>
                        <span class="cal-pill">Week</span>
                        <span class="cal-pill active">Month</span>
                        <button class="cal-today" type="button" id="calToday">Today</button>
                    </div>
                </div>
                <div class="cal-weekdays"><span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span></div>
                <div class="cal-days" id="calDays"></div>
                <div class="cal-legend">
                    <span><i class="dot dot-red"></i>Due date</span>
                    <span><i class="dot dot-blue"></i>Upcoming</span>
                    <span><i class="dot dot-green"></i>Completed</span>
                </div>
            </div>

            <div class="task-scroll" id="taskList">
                <?php if (count($filteredDeadlines) === 0): ?>
                    <div class="empty">No tasks found for this filter.</div>
                <?php else: ?>
                    <?php foreach ($filteredDeadlines as $d): ?>
                        <?php
                        $badgeClass = 'badge-upcoming';
                        $badgeText = 'Upcoming';
                        if ($d['state'] === 'completed') {
                            $badgeClass = 'badge-completed';
                            $badgeText = 'Completed';
                        } elseif ($d['state'] === 'past_due') {
                            $badgeClass = 'badge-past';
                            $badgeText = 'Past Due';
                        }
                        ?>
                        <article class="task-item" data-state="<?php echo htmlspecialchars($d['state']); ?>" data-date="<?php echo htmlspecialchars(substr($d['deadline_datetime'], 0, 10)); ?>">
                            <div class="task-head"><div class="task-title"><?php echo htmlspecialchars($d['title']); ?></div><span class="badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span></div>
                            <div class="task-desc"><?php echo trim((string)$d['description']) !== '' ? htmlspecialchars($d['description']) : 'No description provided.'; ?></div>
                            <div class="task-time"><?php echo htmlspecialchars($d['deadline_datetime']); ?></div>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </main>
</div>

<script>
function updateTopbarDateTime() {
    const liveTime = document.getElementById('liveTime');
    const liveDate = document.getElementById('liveDate');
    if (!liveTime || !liveDate) return;

    const nowDt = new Date();
    liveTime.textContent = nowDt.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
    liveDate.textContent = nowDt.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric'
    });
}

updateTopbarDateTime();
setInterval(updateTopbarDateTime, 30000);

const taskItems = document.querySelectorAll('#taskList .task-item');
let selectedDate = '';
let viewYear;
let viewMonth;
const now = new Date();
viewYear = now.getFullYear();
viewMonth = now.getMonth();

const calTitle = document.getElementById('calTitle');
const calDays = document.getElementById('calDays');
const calPrev = document.getElementById('calPrev');
const calNext = document.getElementById('calNext');
const calToday = document.getElementById('calToday');
const calendarStatusByDate = <?php echo json_encode($calendarStatusByDate); ?>;

function applyDateFilter() {
    taskItems.forEach((item) => {
        const itemDate = item.getAttribute('data-date');
        item.style.display = !selectedDate || selectedDate === itemDate ? '' : 'none';
    });
}

function formatDate(y, m, d) {
    const mm = String(m + 1).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    return `${y}-${mm}-${dd}`;
}

function renderCalendar() {
    calDays.innerHTML = '';
    const firstDay = new Date(viewYear, viewMonth, 1);
    const startWeekday = firstDay.getDay();
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
    calTitle.textContent = firstDay.toLocaleString('en-US', { month: 'long', year: 'numeric' });

    for (let i = 0; i < startWeekday; i++) {
        const blank = document.createElement('button');
        blank.type = 'button';
        blank.className = 'cal-day muted';
        blank.disabled = true;
        calDays.appendChild(blank);
    }

    const today = new Date();
    const todayStr = formatDate(today.getFullYear(), today.getMonth(), today.getDate());
    for (let d = 1; d <= daysInMonth; d++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'cal-day';
        const dateStr = formatDate(viewYear, viewMonth, d);
        btn.textContent = d;
        const status = calendarStatusByDate[dateStr];
        if (status === 'past_due') btn.classList.add('status-past_due');
        if (status === 'upcoming') btn.classList.add('status-upcoming');
        if (status === 'completed') btn.classList.add('status-completed');
        if (dateStr === selectedDate) btn.classList.add('active');
        if (dateStr === todayStr) btn.classList.add('today');
        btn.addEventListener('click', () => {
            selectedDate = dateStr;
            applyDateFilter();
            renderCalendar();
        });
        calDays.appendChild(btn);
    }
}

calPrev.addEventListener('click', () => {
    viewMonth--;
    if (viewMonth < 0) { viewMonth = 11; viewYear--; }
    renderCalendar();
});

calNext.addEventListener('click', () => {
    viewMonth++;
    if (viewMonth > 11) { viewMonth = 0; viewYear++; }
    renderCalendar();
});

calToday.addEventListener('click', () => {
    const t = new Date();
    viewYear = t.getFullYear();
    viewMonth = t.getMonth();
    selectedDate = formatDate(viewYear, viewMonth, t.getDate());
    applyDateFilter();
    renderCalendar();
});

renderCalendar();
</script>
</body>
</html>
