# ✅ Push Notifications Setup Checklist

Follow these steps to get automatic push notifications working:

## Phase 1: Database Setup (2 minutes)

- [ ] Visit `http://localhost/cbuzz/api/setup_push.php`
- [ ] Verify both tables are created (fcm_tokens and deadline_reminder_logs)
- [ ] See JSON response with `"fcm_tokens_verified": true`

## Phase 2: Enable Notifications (3 minutes)

- [ ] Log in to `http://localhost/cbuzz/student/dashboard.php`
- [ ] Browser asks for notification permission
- [ ] Click "Allow"
- [ ] Wait 5 seconds
- [ ] See "Push: Connected" status in bottom-right corner (green)
- [ ] If red, check browser console (F12) for errors

## Phase 3: Verify System (2 minutes)

- [ ] Visit `http://localhost/cbuzz/api/diagnose_push.php`
- [ ] Check all items are green/true:
  - [ ] fcm_tokens_exists: true
  - [ ] deadline_reminder_logs_exists: true
  - [ ] service_account file_exists: true
  - [ ] service_account valid_json: true
  - [ ] service_account has_private_key: true

## Phase 4: Setup Scheduler (5 minutes)

### For Windows:
- [ ] Open Task Scheduler (Win + R, type `taskschd.msc`)
- [ ] Right-click "Task Scheduler Library" → "Create Basic Task"
- [ ] Name: `Classbuzz Reminder Scheduler`
- [ ] Trigger: Daily, repeat every 5 minutes
- [ ] Action: Run `C:\xampp\php\php.exe`
- [ ] Arguments: `C:\xampp\htdocs\cbuzz\api\scheduler.php`
- [ ] Check "Run whether user is logged in or not"
- [ ] Click OK

### For Linux/Mac:
- [ ] Open terminal
- [ ] Run: `crontab -e`
- [ ] Add line: `*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php`
- [ ] Save and exit

## Phase 5: Test It (5 minutes)

- [ ] Create a deadline for 35 minutes from now
  - [ ] Go to admin dashboard
  - [ ] Click "Add Deadline"
  - [ ] Set title and description
  - [ ] Set deadline to 35 minutes from now
  - [ ] Save

- [ ] Wait 5 minutes (or manually trigger)
  - [ ] Visit `http://localhost/cbuzz/api/check_reminders.php`
  - [ ] Should see JSON with `"sent": 1`

- [ ] Check for notification
  - [ ] Look at your device/browser
  - [ ] Should see notification about the deadline

## Phase 6: Monitor (Ongoing)

- [ ] Check admin panel: `http://localhost/cbuzz/admin/scheduler.php`
- [ ] View logs: `logs/scheduler.log` and `logs/reminders.log`
- [ ] Verify reminders are being sent automatically

## Troubleshooting Checklist

### If "Push: Permission denied" (red status):
- [ ] Click lock icon in address bar
- [ ] Find "Notifications" setting
- [ ] Change to "Allow"
- [ ] Refresh page

### If "Push: No token" (red status):
- [ ] Open browser console (F12)
- [ ] Look for error messages
- [ ] Check if VAPID key error
- [ ] Verify you're on HTTPS or localhost

### If "Push: Save failed" (red status):
- [ ] Check if you're logged in
- [ ] Run setup_push.php again
- [ ] Check logs/push_tokens.log for errors

### If no notifications received:
- [ ] Check logs/scheduler.log - is scheduler running?
- [ ] Check logs/reminders.log - are reminders being triggered?
- [ ] Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
- [ ] Verify device is registered (see "Push: Connected")
- [ ] Check if deadline is within reminder window (24h, 12h, 1h, 30m)

### If scheduler doesn't run automatically:
- [ ] Verify Task Scheduler is enabled (Windows)
- [ ] Check cron job is set up (Linux/Mac)
- [ ] Run manually: `php C:\xampp\htdocs\cbuzz\api\scheduler.php`
- [ ] Check logs/scheduler.log for errors

## Quick Reference

| Task | URL |
|------|-----|
| Setup Database | `http://localhost/cbuzz/api/setup_push.php` |
| Enable Notifications | `http://localhost/cbuzz/student/dashboard.php` |
| Run Diagnostics | `http://localhost/cbuzz/api/diagnose_push.php` |
| Check Reminders Now | `http://localhost/cbuzz/api/check_reminders.php` |
| Admin Panel | `http://localhost/cbuzz/admin/scheduler.php` |
| Setup Wizard | `http://localhost/cbuzz/push_setup.php` |

## Log Files

| Log File | Purpose |
|----------|---------|
| `logs/scheduler.log` | Scheduler execution logs |
| `logs/reminders.log` | Reminder check logs |
| `logs/push_tokens.log` | Token registration logs |
| `logs/push_send.log` | Push send logs |

## Documentation

| Document | Purpose |
|----------|---------|
| `README_PUSH_NOTIFICATIONS.md` | Overview and quick links |
| `PUSH_NOTIFICATIONS_QUICK_START.md` | Quick start guide |
| `SCHEDULER_SETUP.md` | Detailed scheduler setup |
| `PUSH_SETUP_GUIDE.md` | Troubleshooting guide |
| `IMPLEMENTATION_COMPLETE.md` | Technical summary |

## Success Indicators

✅ You'll know it's working when:
- [ ] "Push: Connected" shows in green on student dashboard
- [ ] Diagnostics page shows all items as true/green
- [ ] Scheduler logs show regular execution
- [ ] Reminders logs show reminders being triggered
- [ ] You receive notifications on your device

## Next Steps

1. **Start here:** `http://localhost/cbuzz/push_setup.php`
2. **Follow the setup wizard**
3. **Create a test deadline**
4. **Wait for automatic notification**
5. **Monitor logs to ensure everything is working**

---

**Estimated total time: 20 minutes**

Once setup is complete, the system will automatically send you reminders without any further action needed!
