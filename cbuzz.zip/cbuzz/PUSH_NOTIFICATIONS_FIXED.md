# Push Notifications - Fixed & Ready to Use

## What Was Fixed

### 1. **Enhanced firebase.js** ✅
- Added detailed console logging for every step of the registration process
- Improved service worker registration with explicit scope
- Better error messages and status indicators
- Logs now show: permission request, SW registration, token generation, and backend save

### 2. **Improved save_token.php** ✅
- Added request logging to `logs/push_tokens.log`
- Logs all token save attempts with session info
- Helps debug "missing_token_or_session" errors

### 3. **Enhanced send_push.php** ✅
- Added logging to `logs/push_send.log`
- Logs all test requests and results
- Better error tracking for FCM failures

### 4. **New Diagnostic Endpoint** ✅
- Created `/api/diagnose_push.php`
- Checks database tables, service account, and FCM connectivity
- Provides detailed status report in JSON format

### 5. **New Setup Endpoint** ✅
- Created `/api/setup_push.php`
- Automatically creates required database tables
- Verifies table creation success

### 6. **Admin Push Management Panel** ✅
- Created `/admin/push_notifications.php`
- View registered devices and reminder logs
- Send test notifications
- Check reminders manually

### 7. **Comprehensive Setup Guide** ✅
- Created `PUSH_SETUP_GUIDE.md`
- Step-by-step instructions
- Troubleshooting guide
- Log file locations

## Quick Start (3 Steps)

### Step 1: Create Database Tables
```
http://localhost/cbuzz/api/setup_push.php
```

### Step 2: Verify Everything Works
```
http://localhost/cbuzz/api/diagnose_push.php
```

### Step 3: Test It
1. Log in to student dashboard
2. Watch for "Push: Connected" status (bottom-right)
3. Visit `http://localhost/cbuzz/api/send_push.php?test=1` to send a test notification

## Files Created/Modified

### New Files
- `api/diagnose_push.php` - Diagnostic tool
- `api/setup_push.php` - Database setup
- `admin/push_notifications.php` - Admin panel
- `PUSH_SETUP_GUIDE.md` - Setup documentation
- `logs/` directory - For logging (auto-created)

### Modified Files
- `firebase.js` - Enhanced logging
- `api/save_token.php` - Added logging
- `api/send_push.php` - Added logging

## How to Debug Issues

### Check Logs
```bash
# Token save logs
cat logs/push_tokens.log

# Push send logs
cat logs/push_send.log
```

### Browser Console
1. Open student dashboard
2. Press F12 to open DevTools
3. Go to Console tab
4. Look for logs starting with "Requesting notification permission..."
5. Follow the flow to see where it fails

### Network Tab
1. Open DevTools > Network tab
2. Reload the page
3. Look for POST request to `/cbuzz/api/save_token.php`
4. Check response status and body

### Diagnostic Page
Visit `http://localhost/cbuzz/api/diagnose_push.php` to see:
- Database table status
- Service account validity
- FCM connectivity test
- Current user's token status

## Common Issues & Fixes

### "Push: Permission denied"
→ Click lock icon in address bar, allow notifications

### "Push: No token"
→ Check browser console for VAPID key errors
→ Ensure you're on HTTPS or localhost

### "Push: Save failed"
→ Check if you're logged in
→ Run setup_push.php to create tables
→ Check logs/push_tokens.log for details

### Test sends but no notification
→ Check OS notification settings
→ Verify browser notification permission
→ Check if browser is in focus

## Architecture

```
Client (Browser)
    ↓
firebase.js (requests permission, registers SW, gets token)
    ↓
save_token.php (stores token in database)
    ↓
Database (fcm_tokens table)
    ↓
check_reminders.php (triggered by cron or manual)
    ↓
send_push.php (gets OAuth token, sends to FCM)
    ↓
Firebase Cloud Messaging
    ↓
Device (receives notification)
```

## Testing Checklist

- [ ] Run setup_push.php - tables created
- [ ] Run diagnose_push.php - all green
- [ ] Log in to student dashboard
- [ ] See "Push: Connected" status
- [ ] Visit send_push.php?test=1 - get {"sent":1,"failed":0,"error":null}
- [ ] Receive test notification on device
- [ ] Create a deadline
- [ ] Run check_reminders.php?test=1
- [ ] Receive reminder notification

## Support

If push notifications still don't work:

1. Check `PUSH_SETUP_GUIDE.md` for detailed troubleshooting
2. Run `diagnose_push.php` and share the output
3. Check `logs/push_tokens.log` and `logs/push_send.log`
4. Open browser DevTools Console and share any errors
5. Verify service-account.json is from the correct Firebase project

## Next Steps

To make reminders automatic, set up a cron job:

```bash
# Run every 5 minutes
*/5 * * * * curl -s http://localhost/cbuzz/api/check_reminders.php > /dev/null
```

Or use a task scheduler on Windows to call the URL periodically.
