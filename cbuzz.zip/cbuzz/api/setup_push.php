<?php
session_start();
include __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$results = [
    'timestamp' => date('Y-m-d H:i:s'),
    'tables_created' => [],
    'errors' => [],
    'notes' => []
];

// Check if fcm_tokens table exists
$tableRes = $conn->query("SHOW TABLES LIKE 'fcm_tokens'");
$fcmTokensExists = $tableRes && $tableRes->num_rows > 0;

if (!$fcmTokensExists) {
    // Create fcm_tokens table
    $fcmTokensSQL = "CREATE TABLE IF NOT EXISTS fcm_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        token VARCHAR(512) NOT NULL UNIQUE,
        CONSTRAINT fk_fcm_tokens_user
            FOREIGN KEY (user_id) REFERENCES users(id)
            ON DELETE CASCADE
    )";

    if ($conn->query($fcmTokensSQL)) {
        $results['tables_created'][] = 'fcm_tokens';
    } else {
        $results['errors'][] = 'fcm_tokens: ' . $conn->error;
    }
} else {
    $results['notes'][] = 'fcm_tokens table already exists';
}

// Create deadline_reminder_logs table
$reminderLogsSQL = "CREATE TABLE IF NOT EXISTS deadline_reminder_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deadline_id INT NOT NULL,
    reminder_type VARCHAR(20) NOT NULL,
    sent_count INT NOT NULL DEFAULT 0,
    failed_count INT NOT NULL DEFAULT 0,
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_deadline_reminder (deadline_id, reminder_type),
    CONSTRAINT fk_deadline_reminder_logs_deadline
        FOREIGN KEY (deadline_id) REFERENCES deadlines(id)
        ON DELETE CASCADE
)";

if ($conn->query($reminderLogsSQL)) {
    $results['tables_created'][] = 'deadline_reminder_logs';
} else {
    $results['errors'][] = 'deadline_reminder_logs: ' . $conn->error;
}

// Verify tables exist
$tableRes = $conn->query("SHOW TABLES LIKE 'fcm_tokens'");
$results['fcm_tokens_verified'] = $tableRes && $tableRes->num_rows > 0;

$logsRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
$results['deadline_reminder_logs_verified'] = $logsRes && $logsRes->num_rows > 0;

echo json_encode($results, JSON_PRETTY_PRINT);
?>
