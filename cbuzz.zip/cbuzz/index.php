<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Classbuzz - Student Reminder System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg: #f4f6f8;
        --surface: #ffffff;
        --text: #1e2228;
        --muted: #5d6674;
        --brand: #cfa430;
        --brand-deep: #9f7d1d;
        --ink: #101216;
        --line: #e6e9ef;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: "Sora", sans-serif;
        background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
        color: var(--text);
        line-height: 1.6;
    }

    a {
        text-decoration: none;
    }

    nav {
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 40px;
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--line);
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--ink);
        font-weight: 700;
        font-size: 22px;
    }

    .logo img {
        width: 34px;
        height: 34px;
    }

    nav ul {
        list-style: none;
        display: flex;
        gap: 20px;
        align-items: center;
    }

    nav ul a {
        color: var(--ink);
        font-weight: 500;
        transition: color 0.2s ease;
    }

    nav ul a:hover {
        color: var(--brand-deep);
    }

    .nav-cta {
        background: var(--ink);
        color: #fff;
        padding: 10px 16px;
        border-radius: 999px;
    }

    .nav-cta:hover {
        color: #fff;
        background: #1b1e24;
    }

    .hero {
        max-width: 1180px;
        margin: 34px auto 24px;
        padding: 0 24px;
        display: grid;
        grid-template-columns: 1.15fr 0.85fr;
        gap: 26px;
    }

    .hero-copy {
        background:
            linear-gradient(120deg, rgba(23, 26, 32, 0.8) 0%, rgba(35, 40, 52, 0.88) 100%),
            url("images/deadline.jpg") center/cover no-repeat;
        color: #fff;
        border-radius: 22px;
        padding: 42px;
        box-shadow: 0 16px 40px rgba(16, 18, 22, 0.18);
    }

    .eyebrow {
        color: #f0d184;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        font-size: 12px;
        font-weight: 700;
    }

    .hero h1 {
        margin-top: 10px;
        font-family: "Source Serif 4", serif;
        font-size: clamp(2rem, 3vw, 3rem);
        line-height: 1.1;
    }

    .hero p {
        margin-top: 16px;
        color: #e2e7f2;
        max-width: 60ch;
    }

    .hero-actions {
        margin-top: 26px;
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .btn {
        padding: 12px 18px;
        border-radius: 10px;
        font-weight: 600;
        display: inline-block;
        border: none;
    }

    .btn-primary {
        background: var(--brand);
        color: #18120a;
    }

    .btn-secondary {
        border: 1px solid #6d7689;
        color: #f3f5f9;
    }

    .hero-stat {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 22px;
        padding: 28px;
        display: grid;
        gap: 16px;
        align-content: center;
    }

    .metric-row {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        padding-bottom: 14px;
        border-bottom: 1px dashed #d9dde5;
    }

    .metric-row:last-child {
        border-bottom: none;
        padding-bottom: 0;
    }

    .metric-row strong {
        font-size: 34px;
        color: var(--ink);
    }

    .content {
        max-width: 1180px;
        margin: 0 auto;
        padding: 14px 24px 62px;
    }

    .section-title {
        font-family: "Source Serif 4", serif;
        font-size: clamp(1.6rem, 2vw, 2.2rem);
        margin-bottom: 8px;
    }

    .section-sub {
        color: var(--muted);
        margin-bottom: 24px;
    }

    .feature-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 28px;
    }

    .feature-card {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 14px;
        padding: 18px;
        text-align: center;
    }

    .feature-card img {
        width: 72px;
        height: 72px;
        object-fit: cover;
        border-radius: 10px;
        margin-bottom: 10px;
    }

    .feature-card h3 {
        margin-bottom: 6px;
        color: var(--ink);
        font-size: 17px;
    }

    .feature-card p {
        color: var(--muted);
        font-size: 14px;
    }

    .cta {
        margin-top: 12px;
        background: linear-gradient(95deg, #12151b 0%, #222837 100%);
        border-radius: 18px;
        color: #f4f6fb;
        padding: 24px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
    }

    .cta p {
        color: #c4cbda;
    }

    footer {
        text-align: center;
        padding: 22px;
        color: #6c7482;
        font-size: 14px;
    }

    @media (max-width: 1024px) {
        .hero {
            grid-template-columns: 1fr;
        }

        .feature-grid {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 760px) {
        nav {
            padding: 14px 16px;
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }

        nav ul {
            gap: 14px;
            flex-wrap: wrap;
        }

        .hero,
        .content {
            padding-left: 16px;
            padding-right: 16px;
        }

        .hero-copy {
            padding: 26px 20px;
        }

        .feature-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<nav>
    <a class="logo" href="index.php">
        <img src="images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <ul>
        <li><a href="#features">Features</a></li>
        <li><a href="about_us.php">About Us</a></li>
        <li><a class="nav-cta" href="auth/login.php">Login</a></li>
    </ul>
</nav>

<section class="hero">
    <div class="hero-copy">
        <div class="eyebrow">Student-first platform</div>
        <h1>Stay On Top Of Deadlines Without The Stress</h1>
        <p>Classbuzz helps students organize schoolwork, track tasks clearly, and get reminders that keep submissions on time.</p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="auth/register.php">Get Started</a>
            <a class="btn btn-secondary" href="#features">View Features</a>
        </div>
    </div>
    <aside class="hero-stat">
        <div class="metric-row">
            <span>Assignments tracked</span>
            <strong>15k+</strong>
        </div>
        <div class="metric-row">
            <span>Reliability</span>
            <strong>93%</strong>
        </div>
        <div class="metric-row">
            <span>On-time submissions</span>
            <strong>94%</strong>
        </div>
    </aside>
</section>

<main class="content">
    <h2 class="section-title">Core Features</h2>
    <p class="section-sub" id="features">Built to be clean, easy, and useful in your everyday school workflow.</p>

    <section class="feature-grid">
        <article class="feature-card">
            <img src="images/reminder.jpg" alt="Deadline reminders">
            <h3>Deadline Reminders</h3>
            <p>Automatic reminders for assignments and exams so you never miss a submission.</p>
        </article>
        <article class="feature-card">
            <img src="images/tasks.jpg" alt="Organized dashboard">
            <h3>Organized Dashboard</h3>
            <p>View all tasks and due dates in one place with a straightforward layout.</p>
        </article>
        <article class="feature-card">
            <img src="images/login.jpg" alt="Any device access">
            <h3>Access Anywhere</h3>
            <p>Sign in from any device and stay updated on deadlines wherever you are.</p>
        </article>
    </section>

    <section class="cta">
        <div>
            <h3>Ready to make your school routine easier?</h3>
            <p>Create your account and start tracking deadlines the simple way.</p>
        </div>
        <a class="btn btn-primary" href="auth/register.php">Join Classbuzz</a>
    </section>
</main>

<footer>
    &copy; 2026 Classbuzz. All rights reserved.
</footer>

</body>
</html>
