# Automatic Reminder Notifications Setup

## Overview

Your push notifications are now set up to send reminders automatically. The system will check for upcoming deadlines every 5 minutes and send notifications to all registered devices.

## How It Works

1. **Scheduler runs every 5 minutes** - Checks all deadlines
2. **Finds upcoming deadlines** - Looks for deadlines within reminder windows:
   - 24 hours before deadline
   - 12 hours before deadline
   - 1 hour before deadline
   - 30 minutes before deadline
3. **Sends notifications** - Sends push notification to all registered devices
4. **Prevents duplicates** - Won't send the same reminder twice

## Setup Instructions

### Option 1: Windows Task Scheduler (Recommended for Windows)

#### Step 1: Open Task Scheduler
1. Press `Win + R`
2. Type `taskschd.msc` and press Enter
3. Click "Task Scheduler Library" on the left

#### Step 2: Create New Task
1. Right-click "Task Scheduler Library" → "Create Basic Task"
2. Name: `Classbuzz Reminder Scheduler`
3. Description: `Sends push notifications for upcoming deadlines`
4. Click "Next"

#### Step 3: Set Trigger
1. Select "Daily"
2. Click "Next"
3. Click "New..." button
4. Set to repeat every 5 minutes
5. Click "OK" → "Next"

#### Step 4: Set Action
1. Select "Start a program"
2. Click "Next"
3. Program/script: `C:\xampp\php\php.exe`
4. Add arguments: `C:\xampp\htdocs\cbuzz\api\scheduler.php`
5. Start in: `C:\xampp\htdocs\cbuzz`
6. Click "Next"

#### Step 5: Finish
1. Check "Open the Properties dialog for this task when I click Finish"
2. Click "Finish"
3. In Properties, go to "General" tab
4. Check "Run whether user is logged in or not"
5. Click "OK"

### Option 2: Linux/Mac Cron Job

Add this line to your crontab:

```bash
# Edit crontab
crontab -e

# Add this line (runs every 5 minutes)
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php
```

### Option 3: Manual Testing

To test the scheduler manually, visit:
```
http://localhost/cbuzz/api/check_reminders.php
```

Or run from command line:
```bash
php C:\xampp\htdocs\cbuzz\api\scheduler.php
```

## Monitoring

### View Scheduler Logs

Check the scheduler logs to see what's happening:

```bash
# View recent logs
tail -f logs/scheduler.log

# Or on Windows, open the file
C:\xampp\htdocs\cbuzz\logs\scheduler.log
```

### Log Format

Each run logs:
- Start/end time
- Current time
- Deadlines found
- Notifications sent
- Any errors

Example log:
```
[2026-03-01 22:45:00] === Scheduler Started ===
[2026-03-01 22:45:00] Current time: 2026-03-01 22:45:00
[2026-03-01 22:45:02] Deadline 'Math Assignment' (ID: 5) is due in 1h
[2026-03-01 22:45:02]   → Sending notification: Math Assignment is due in 1h.
[2026-03-01 22:45:03]   → Sent: 3, Failed: 0
[2026-03-01 22:45:03] === Scheduler Completed ===
[2026-03-01 22:45:03] Triggered: 1, Sent: 3, Failed: 0
```

## Troubleshooting

### Task doesn't run automatically

**Check if task is enabled:**
1. Open Task Scheduler
2. Find "Classbuzz Reminder Scheduler"
3. Right-click → "Enable"

**Check task history:**
1. Right-click task → "View History"
2. Look for errors

**Run manually to test:**
```bash
php C:\xampp\htdocs\cbuzz\api\scheduler.php
```

### No notifications received

1. Check `logs/scheduler.log` - Are reminders being triggered?
2. Check `logs/push_send.log` - Are notifications being sent?
3. Run diagnostics: `http://localhost/cbuzz/api/diagnose_push.php`
4. Verify you're logged in and have registered a device

### Task runs but nothing happens

1. Check if fcm_tokens table has registered devices
2. Check if there are any deadlines in the database
3. Check if deadlines are within reminder windows
4. Check logs for errors

## Testing

### Create a Test Deadline

1. Log in as admin
2. Go to "Add Deadline"
3. Create a deadline for 35 minutes from now
4. Save

### Run Scheduler Manually

```bash
php C:\xampp\htdocs\cbuzz\api\scheduler.php
```

### Check Logs

```bash
tail -f logs/scheduler.log
```

You should see the deadline being triggered and notifications being sent.

### Receive Notification

Check your device for a push notification about the deadline.

## Reminder Windows

The system sends reminders at these times before the deadline:

| Reminder | Time Before Deadline |
|----------|---------------------|
| 24h      | 24 hours            |
| 12h      | 12 hours            |
| 1h       | 1 hour              |
| 30m      | 30 minutes          |

Each reminder is only sent once per deadline.

## Advanced Configuration

### Change Reminder Times

Edit `api/scheduler.php` and modify the `$reminders` array:

```php
$reminders = [
    "24h" => 86400,    // 24 hours
    "12h" => 43200,    // 12 hours
    "1h" => 3600,      // 1 hour
    "30m" => 1800      // 30 minutes
];
```

### Change Check Frequency

To run more or less frequently, adjust the task scheduler:
- Every 1 minute: `*/1 * * * *`
- Every 5 minutes: `*/5 * * * *` (default)
- Every 10 minutes: `*/10 * * * *`
- Every 30 minutes: `*/30 * * * *`

### Change Tolerance Window

Edit `api/scheduler.php` and modify:

```php
$toleranceSeconds = 300; // 5 minute window
```

This allows reminders to be sent within ±5 minutes of the target time.

## Support

If reminders still aren't working:

1. **Verify setup:**
   - Run `http://localhost/cbuzz/api/setup_push.php`
   - Run `http://localhost/cbuzz/api/diagnose_push.php`

2. **Check logs:**
   - `logs/scheduler.log` - Scheduler activity
   - `logs/push_send.log` - Push send attempts
   - `logs/push_tokens.log` - Token registration

3. **Test manually:**
   - Run scheduler: `php api/scheduler.php`
   - Send test: `http://localhost/cbuzz/api/send_push.php?test=1`

4. **Verify prerequisites:**
   - Logged in to student dashboard
   - Device registered (see "Push: Connected" status)
   - Deadline created in database
   - Deadline is within reminder window
