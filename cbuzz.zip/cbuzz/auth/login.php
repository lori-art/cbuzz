<?php
session_start();
include "../config/db.php";

 $error = "";

if($_SERVER['REQUEST_METHOD']=="POST"){
    $email = trim($_POST['email']);
    $password = MD5($_POST['password']);

    $res = $conn->query("SELECT * FROM users WHERE email='$email' AND password='$password'");
    if($res->num_rows>0){
        $user = $res->fetch_assoc();
        $_SESSION['user'] = $user;

        if($user['role']=="admin"){
            header("Location: ../admin/dashboard.php");
            exit;
        } else {
            header("Location: ../student/dashboard.php");
            exit;
        }
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Classbuzz</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg: #f4f6f8;
        --surface: #ffffff;
        --text: #1e2228;
        --muted: #5d6674;
        --brand: #cfa430;
        --brand-deep: #9f7d1d;
        --ink: #101216;
        --line: #e6e9ef;
        --danger-bg: #fff1f1;
        --danger-text: #9f2323;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: "Sora", sans-serif;
        background: radial-gradient(circle at 10% -10%, #fff7de 0%, var(--bg) 46%), var(--bg);
        color: var(--text);
        min-height: 100vh;
    }

    a {
        text-decoration: none;
    }

    nav {
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 40px;
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--line);
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--ink);
        font-weight: 700;
        font-size: 22px;
    }

    .logo img {
        width: 34px;
        height: 34px;
    }

    nav ul {
        list-style: none;
        display: flex;
        gap: 20px;
        align-items: center;
    }

    nav ul a {
        color: var(--ink);
        font-weight: 500;
        transition: color 0.2s ease;
    }

    nav ul a:hover {
        color: var(--brand-deep);
    }

    .nav-cta {
        background: var(--ink);
        color: #fff;
        padding: 10px 16px;
        border-radius: 999px;
    }

    .nav-cta:hover {
        color: #fff;
        background: #1b1e24;
    }

    .wrap {
        max-width: 1180px;
        margin: 34px auto;
        padding: 0 24px 34px;
        display: grid;
        grid-template-columns: 1fr 420px;
        gap: 24px;
        align-items: stretch;
    }

    .intro {
        background:
            linear-gradient(120deg, rgba(23, 26, 32, 0.86) 0%, rgba(35, 40, 52, 0.9) 100%),
            url("../images/deadline.jpg") center/cover no-repeat;
        border-radius: 22px;
        color: #fff;
        padding: 42px;
        box-shadow: 0 16px 40px rgba(16, 18, 22, 0.18);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .eyebrow {
        color: #f0d184;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        font-size: 12px;
        font-weight: 700;
    }

    .intro h1 {
        margin-top: 10px;
        font-family: "Source Serif 4", serif;
        font-size: clamp(2rem, 3vw, 2.8rem);
        line-height: 1.1;
        max-width: 18ch;
    }

    .intro p {
        margin-top: 14px;
        color: #e2e7f2;
        max-width: 52ch;
    }

    .stats {
        margin-top: 24px;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }

    .stat {
        background: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 12px;
    }

    .stat strong {
        display: block;
        font-size: 20px;
    }

    .stat span {
        font-size: 12px;
        color: #d4d9e7;
    }

    .auth-card {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 22px;
        padding: 28px;
        box-shadow: 0 14px 28px rgba(17, 22, 31, 0.06);
    }

    .auth-card h2 {
        font-family: "Source Serif 4", serif;
        font-size: 32px;
        color: var(--ink);
        margin-bottom: 6px;
    }

    .auth-card .sub {
        color: var(--muted);
        margin-bottom: 20px;
        font-size: 14px;
    }

    .error {
        background: var(--danger-bg);
        color: var(--danger-text);
        border: 1px solid #ffd9d9;
        padding: 10px 12px;
        border-radius: 10px;
        margin-bottom: 14px;
        font-size: 14px;
    }

    .field {
        margin-bottom: 14px;
    }

    label {
        display: block;
        font-size: 13px;
        color: var(--muted);
        margin-bottom: 6px;
        font-weight: 600;
    }

    input {
        width: 100%;
        border: 1px solid var(--line);
        border-radius: 10px;
        padding: 12px 14px;
        font-size: 15px;
        font-family: inherit;
        color: var(--text);
        background: #fff;
    }

    input:focus {
        outline: none;
        border-color: #d7bc6b;
        box-shadow: 0 0 0 4px rgba(207, 164, 48, 0.16);
    }

    button {
        width: 100%;
        border: none;
        border-radius: 10px;
        padding: 12px 16px;
        background: var(--brand);
        color: #18120a;
        font-weight: 700;
        font-family: inherit;
        font-size: 15px;
        cursor: pointer;
    }

    button:hover {
        background: #d9ae3c;
    }

    .helper {
        margin-top: 12px;
        font-size: 13px;
        color: var(--muted);
        text-align: center;
    }

    .helper a {
        color: var(--brand-deep);
        font-weight: 600;
    }

    @media (max-width: 980px) {
        .wrap {
            grid-template-columns: 1fr;
        }

        .stats {
            grid-template-columns: 1fr 1fr 1fr;
        }
    }

    @media (max-width: 760px) {
        nav {
            padding: 14px 16px;
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
        }

        nav ul {
            gap: 14px;
            flex-wrap: wrap;
        }

        .wrap {
            margin-top: 22px;
            padding-left: 16px;
            padding-right: 16px;
        }

        .intro {
            padding: 28px 20px;
        }

        .stats {
            grid-template-columns: 1fr;
        }

        .auth-card {
            padding: 22px 18px;
        }
    }
</style>
</head>
<body>
<nav>
    <a class="logo" href="../index.php">
        <img src="../images/classbuzz-logo.svg" alt="Classbuzz logo">
        <span>Classbuzz</span>
    </a>
    <ul>
        <li><a href="../index.php">Home</a></li>
        <li><a href="../about_us.php">About Us</a></li>
        <li><a class="nav-cta" href="register.php">Register</a></li>
    </ul>
</nav>

<main class="wrap">
    <section class="intro">
        <div>
            <div class="eyebrow">Welcome back</div>
            <h1>Continue Managing Deadlines With Confidence</h1>
            <p>Log in to track assignments, get reminders, and stay organized with Classbuzz.</p>
        </div>
        <div class="stats">
            <div class="stat">
                <strong>15k+</strong>
                <span>Tasks tracked</span>
            </div>
            <div class="stat">
                <strong>2,000+</strong>
                <span>Active learners</span>
            </div>
            <div class="stat">
                <strong>94%</strong>
                <span>On-time rate</span>
            </div>
        </div>
    </section>

    <section class="auth-card">
        <h2>Login</h2>
        <p class="sub">Enter your account details to continue.</p>

        <?php if($error !== ""): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" placeholder="you@example.com" required>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit">Login</button>
        </form>

        <p class="helper">No account yet? <a href="register.php">Create one</a></p>
    </section>
</main>
</body>
</html>
