# Push Notifications - Complete Setup Guide

## What You Have Now

Your Classbuzz system now has **fully automatic push notifications** that will remind you about upcoming deadlines without needing to open any tabs.

## How It Works

1. **You create a deadline** in the admin panel
2. **Scheduler runs every 5 minutes** and checks for upcoming deadlines
3. **Notifications are sent automatically** at these times:
   - 24 hours before deadline
   - 12 hours before deadline
   - 1 hour before deadline
   - 30 minutes before deadline
4. **You receive notifications** on your device (even if you're not using the app)

## Quick Start (5 Minutes)

### Step 1: Set Up Database Tables
Visit this URL in your browser:
```
http://localhost/cbuzz/api/setup_push.php
```

You should see:
```json
{
  "fcm_tokens_verified": true,
  "deadline_reminder_logs_verified": true
}
```

### Step 2: Enable Notifications on Your Device
1. Log in to student dashboard: `http://localhost/cbuzz/student/dashboard.php`
2. Click "Allow" when asked for notification permission
3. Wait for "Push: Connected" status in bottom-right corner (green)

### Step 3: Set Up Automatic Scheduler

**For Windows (Recommended):**

1. Open Task Scheduler (press `Win + R`, type `taskschd.msc`)
2. Right-click "Task Scheduler Library" → "Create Basic Task"
3. Name: `Classbuzz Reminder Scheduler`
4. Trigger: Daily, repeat every 5 minutes
5. Action: Run `C:\xampp\php\php.exe` with arguments `C:\xampp\htdocs\cbuzz\api\scheduler.php`
6. Check "Run whether user is logged in or not"

**For Linux/Mac:**

Add to crontab:
```bash
*/5 * * * * /usr/bin/php /var/www/html/cbuzz/api/scheduler.php
```

### Step 4: Test It
1. Create a deadline for 35 minutes from now
2. Wait 5 minutes (or manually trigger: `http://localhost/cbuzz/api/check_reminders.php`)
3. You should receive a notification!

## Verify Everything Works

### Check 1: Database Setup
```
http://localhost/cbuzz/api/setup_push.php
```
Should show both tables verified ✅

### Check 2: System Diagnostics
```
http://localhost/cbuzz/api/diagnose_push.php
```
Should show:
- fcm_tokens_exists: true
- service_account valid
- OAuth connectivity working

### Check 3: Device Registration
1. Log in to student dashboard
2. Check bottom-right corner for "Push: Connected" (green)
3. Open browser DevTools (F12) > Console
4. Should see logs like "FCM token obtained: ..."

### Check 4: Manual Reminder Check
```
http://localhost/cbuzz/api/check_reminders.php
```
Should return JSON with sent count

## Admin Panel

Access the scheduler management panel:
```
http://localhost/cbuzz/admin/scheduler.php
```

Here you can:
- View statistics (deadlines, devices, reminders)
- Check reminders manually
- View recent reminders sent
- Monitor scheduler logs

## Troubleshooting

### "Push: Permission denied" (red status)
→ Click lock icon in address bar, allow notifications

### "Push: No token" (red status)
→ Check browser console (F12) for errors
→ Ensure you're on HTTPS or localhost

### Scheduler doesn't run automatically
→ Check Task Scheduler is enabled
→ Run manually: `php C:\xampp\htdocs\cbuzz\api\scheduler.php`
→ Check logs: `logs/scheduler.log`

### No notifications received
→ Check if device is registered (see "Push: Connected")
→ Check if deadline is within reminder window
→ Check logs: `logs/reminders.log`

## Log Files

Monitor these files to debug issues:

```
logs/
├── push_tokens.log      # Token registration attempts
├── push_send.log        # Push send attempts
├── reminders.log        # Reminder check logs
└── scheduler.log        # Scheduler execution logs
```

View logs:
```bash
# Windows
type logs\reminders.log

# Linux/Mac
tail -f logs/reminders.log
```

## Files Created

- `api/scheduler.php` - Background scheduler (runs every 5 minutes)
- `api/check_reminders.php` - Reminder checker (can be called manually)
- `admin/scheduler.php` - Admin panel for managing reminders
- `SCHEDULER_SETUP.md` - Detailed setup instructions
- `logs/` - Directory for log files

## Testing Checklist

- [ ] Run setup_push.php - tables created
- [ ] Log in to student dashboard
- [ ] See "Push: Connected" status
- [ ] Create a deadline
- [ ] Run check_reminders.php manually
- [ ] Receive notification on device
- [ ] Set up Windows Task Scheduler or cron job
- [ ] Wait 5 minutes for automatic check
- [ ] Receive automatic notification

## Next Steps

1. **Set up the scheduler** (Windows Task Scheduler or cron)
2. **Create some deadlines** in the admin panel
3. **Wait for automatic notifications** (or manually trigger check_reminders.php)
4. **Monitor logs** to ensure everything is working

## Support

If something isn't working:

1. Check `logs/reminders.log` for errors
2. Run `http://localhost/cbuzz/api/diagnose_push.php`
3. Check browser console (F12) for client-side errors
4. Verify scheduler is running (check Task Scheduler or cron logs)
5. Manually trigger: `http://localhost/cbuzz/api/check_reminders.php`

## Architecture

```
┌────────────────────��────────────────────────────────────┐
│                    Windows/Linux                        │
│              Task Scheduler / Cron Job                  │
│                  (Every 5 minutes)                      │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
        ┌────────────────────────────┐
        │   scheduler.php or         │
        │   check_reminders.php      │
        │  (Checks for deadlines)    │
        └────────────┬───────────────┘
                     │
                     ▼
        ┌────────────────────────────┐
        │   send_push.php            │
        │  (Sends to Firebase)       │
        └────────────┬───────────────┘
                     │
                     ▼
        ┌────────────────────────────┐
        │  Firebase Cloud Messaging  │
        └────────────┬───────────────┘
                     │
                     ▼
        ┌────────────────────────────┐
        │   Your Device              │
        │  (Receives notification)   │
        └────────────────────────────┘
```

## Reminder Schedule

| Reminder | Time Before Deadline |
|----------|---------------------|
| 1st      | 24 hours            |
| 2nd      | 12 hours            |
| 3rd      | 1 hour              |
| 4th      | 30 minutes          |

Each reminder is sent only once per deadline.

---

**You're all set!** Your push notifications are now ready to automatically remind you about upcoming deadlines. 🎉
