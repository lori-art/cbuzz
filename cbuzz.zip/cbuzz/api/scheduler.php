<?php
/**
 * Automated Reminder Scheduler
 * This script should be called every 5 minutes by a cron job or task scheduler
 * 
 * Windows Task Scheduler:
 * - Action: Start a program
 * - Program: C:\xampp\php\php.exe
 * - Arguments: C:\xampp\htdocs\cbuzz\api\scheduler.php
 * - Repeat: Every 5 minutes
 * 

 */

// Prevent timeout
set_time_limit(60);

// Log file
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/scheduler.log';

function log_message($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] $message\n";
    @file_put_contents($logFile, $entry, FILE_APPEND);
    echo $entry;
}

log_message("=== Scheduler Started ===");

try {
    // Include database connection
    include __DIR__ . '/../config/db.php';
    
    // Include push notification functions
    include __DIR__ . '/send_push.php';
    
    // Get current time
    $now = time();
    log_message("Current time: " . date('Y-m-d H:i:s', $now));
    
    // Fetch all deadlines
    $res = $conn->query("SELECT id, title, deadline_datetime FROM deadlines");
    if (!$res) {
        log_message("ERROR: Failed to fetch deadlines - " . $conn->error);
        exit(1);
    }
    
    // Check if reminder logs table exists
    $hasReminderLogsTable = false;
    $logsTableRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
    if ($logsTableRes && $logsTableRes->num_rows > 0) {
        $hasReminderLogsTable = true;
    }
    
    $triggered = 0;
    $totalSent = 0;
    $totalFailed = 0;
    
    // Define reminder times (in seconds before deadline)
    $reminders = [
        "24h" => 86400,    // 24 hours
        "12h" => 43200,    // 12 hours
        "1h" => 3600,      // 1 hour
        "30m" => 1800      // 30 minutes
    ];
    
    $toleranceSeconds = 300; // 5 minute window
    
    // Check each deadline
    while ($row = $res->fetch_assoc()) {
        $deadline = strtotime($row['deadline_datetime']);
        if ($deadline === false) {
            continue;
        }
        
        $diff = $deadline - $now;
        $deadlineId = (int)$row['id'];
        $title = htmlspecialchars($row['title']);
        
        // Check each reminder type
        foreach ($reminders as $label => $targetSeconds) {
            // Check if this deadline is within the reminder window
            if (abs($diff - $targetSeconds) <= $toleranceSeconds) {
                log_message("Deadline '$title' (ID: $deadlineId) is due in $label");
                
                // Check if we already sent this reminder
                if ($hasReminderLogsTable) {
                    $checkStmt = $conn->prepare("
                        SELECT id FROM deadline_reminder_logs
                        WHERE deadline_id = ? AND reminder_type = ?
                        LIMIT 1
                    ");
                    if ($checkStmt) {
                        $checkStmt->bind_param("is", $deadlineId, $label);
                        $checkStmt->execute();
                        $alreadySent = $checkStmt->get_result();
                        if ($alreadySent && $alreadySent->num_rows > 0) {
                            log_message("  → Already sent, skipping");
                            continue;
                        }
                    }
                }
                
                // Send notification
                $body = "$title is due in $label.";
                log_message("  → Sending notification: $body");
                
                $result = send_push_notifications("Deadline Reminder", $body, [
                    "deadline_id" => (string)$deadlineId,
                    "reminder_type" => $label
                ]);
                
                $sent = isset($result['sent']) ? (int)$result['sent'] : 0;
                $failed = isset($result['failed']) ? (int)$result['failed'] : 0;
                
                log_message("  → Sent: $sent, Failed: $failed");
                
                $triggered++;
                $totalSent += $sent;
                $totalFailed += $failed;
                
                if (isset($result['error']) && $result['error'] !== null) {
                    log_message("  → Error: " . $result['error']);
                }
                
                // Log the reminder
                if ($hasReminderLogsTable) {
                    $logStmt = $conn->prepare("
                        INSERT INTO deadline_reminder_logs (deadline_id, reminder_type, sent_count, failed_count, sent_at)
                        VALUES (?, ?, ?, ?, NOW())
                    ");
                    if ($logStmt) {
                        $logStmt->bind_param("isii", $deadlineId, $label, $sent, $failed);
                        $logStmt->execute();
                    }
                }
            }
        }
    }
    
    log_message("=== Scheduler Completed ===");
    log_message("Triggered: $triggered, Sent: $totalSent, Failed: $totalFailed");
    log_message("");
    
} catch (Exception $e) {
    log_message("EXCEPTION: " . $e->getMessage());
    exit(1);
}

exit(0);
?>
