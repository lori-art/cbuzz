<?php
/**
 * Web-based Reminder Checker
 * Can be called via cron job or manually
 * Usage: curl http://localhost/cbuzz/api/check_reminders.php
 */

include __DIR__ . "/../config/db.php";
include __DIR__ . "/send_push.php";

// Log file
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/reminders.log';

function log_reminder($message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] $message\n";
    @file_put_contents($logFile, $entry, FILE_APPEND);
}

$now = time();
$isTestMode = isset($_GET['test']) && $_GET['test'] === '1';
$toleranceSeconds = $isTestMode ? 15 : 300; // 5 minute window for normal mode

log_reminder("=== Reminder Check Started (Mode: " . ($isTestMode ? "TEST" : "NORMAL") . ") ===");

$res = $conn->query("SELECT id, title, deadline_datetime FROM deadlines");
if (!$res) {
    log_reminder("ERROR: Failed to fetch deadlines - " . $conn->error);
    http_response_code(500);
    echo json_encode([
        "ok" => false,
        "error" => "Failed to fetch deadlines",
        "db_error" => $conn->error
    ]);
    exit;
}

$hasReminderLogsTable = false;
$logsTableRes = $conn->query("SHOW TABLES LIKE 'deadline_reminder_logs'");
if ($logsTableRes && $logsTableRes->num_rows > 0) {
    $hasReminderLogsTable = true;
}

$triggered = 0;
$totalSent = 0;
$totalFailed = 0;
$lastError = null;

while ($row = $res->fetch_assoc()) {
    $deadline = strtotime($row['deadline_datetime']);
    if ($deadline === false) {
        continue;
    }
    $diff = $deadline - $now;

    $reminders = $isTestMode
        ? ["30s_test" => 30]
        : [
            "24h" => 86400,
            "12h" => 43200,
            "1h" => 3600,
            "30m" => 1800
        ];

    foreach ($reminders as $label => $targetSeconds) {
        if (abs($diff - $targetSeconds) <= $toleranceSeconds) {
            $deadlineId = (int)$row['id'];

            // Prevent duplicate notifications for the same reminder stage.
            if ($hasReminderLogsTable) {
                $checkStmt = $conn->prepare("
                    SELECT id
                    FROM deadline_reminder_logs
                    WHERE deadline_id = ? AND reminder_type = ?
                    LIMIT 1
                ");
                if ($checkStmt) {
                    $checkStmt->bind_param("is", $deadlineId, $label);
                    $checkStmt->execute();
                    $alreadySent = $checkStmt->get_result();
                    if ($alreadySent && $alreadySent->num_rows > 0) {
                        log_reminder("Deadline ID $deadlineId - $label reminder already sent, skipping");
                        continue;
                    }
                }
            }

            $title = "Deadline Reminder";
            $body = $isTestMode
                ? $row['title'] . " is due in 30 seconds (test)."
                : $row['title'] . " is due in " . $label . ".";

            log_reminder("Sending reminder for deadline ID $deadlineId: $body");

            $result = send_push_notifications($title, $body, [
                "deadline_id" => (string)$deadlineId,
                "reminder_type" => $label
            ]);

            $sent = isset($result['sent']) ? (int)$result['sent'] : 0;
            $failed = isset($result['failed']) ? (int)$result['failed'] : 0;
            $triggered++;
            $totalSent += $sent;
            $totalFailed += $failed;
            if (isset($result['error']) && $result['error'] !== null) {
                $lastError = $result['error'];
                log_reminder("Error: " . $result['error']);
            }

            log_reminder("Result: Sent=$sent, Failed=$failed");

            if ($hasReminderLogsTable) {
                $logStmt = $conn->prepare("
                    INSERT INTO deadline_reminder_logs (deadline_id, reminder_type, sent_count, failed_count, sent_at)
                    VALUES (?, ?, ?, ?, NOW())
                ");
                if ($logStmt) {
                    $logStmt->bind_param("isii", $deadlineId, $label, $sent, $failed);
                    $logStmt->execute();
                }
            }
        }
    }
}

log_reminder("=== Reminder Check Completed ===");
log_reminder("Total Triggered: $triggered, Sent: $totalSent, Failed: $totalFailed\n");

header("Content-Type: application/json");
echo json_encode([
    "ok" => true,
    "mode" => $isTestMode ? "test_30_seconds" : "normal",
    "triggered" => $triggered,
    "sent" => $totalSent,
    "failed" => $totalFailed,
    "has_reminder_logs_table" => $hasReminderLogsTable,
    "error" => $lastError
]);
?>
