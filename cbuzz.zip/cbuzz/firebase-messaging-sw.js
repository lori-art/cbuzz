importScripts("https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCPhUXosh6YAmufvin64W2P9FC4ll46Psk",
  authDomain: "capstone-e841f.firebaseapp.com",
  projectId: "capstone-e841f",
  messagingSenderId: "358000455074",
  appId: "1:358000455074:web:23683661492484109a96fb",
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  self.registration.showNotification(payload.notification.title, {
    body: payload.notification.body
  });
});