<?php
session_start();
include __DIR__ . '/../config/db.php';

// Log all requests for debugging
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/push_tokens.log';
$logEntry = date('Y-m-d H:i:s') . " | " . $_SERVER['REQUEST_METHOD'] . " | ";
$logEntry .= "Session user: " . (isset($_SESSION['user']) ? json_encode($_SESSION['user']) : 'none') . " | ";
$logEntry .= "POST token: " . (isset($_POST['token']) ? substr($_POST['token'], 0, 20) . '...' : 'none') . "\n";
@file_put_contents($logFile, $logEntry, FILE_APPEND);

if (!isset($_POST['token']) || !isset($_SESSION['user'])) {
    http_response_code(400);
    echo "missing_token_or_session";
    exit;
}

$token = trim((string)$_POST['token']);
$user_id = isset($_SESSION['user']['id']) ? (int)$_SESSION['user']['id'] : 0;

if ($user_id <= 0 && isset($_SESSION['user']['email'])) {
    $safeEmail = $conn->real_escape_string($_SESSION['user']['email']);
    $res = $conn->query("SELECT id FROM users WHERE email='$safeEmail' LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $user_id = (int)$res->fetch_assoc()['id'];
        $_SESSION['user']['id'] = $user_id;
    }
}

if ($token === '' || $user_id <= 0) {
    http_response_code(400);
    echo "invalid_payload";
    exit;
}
if (strlen($token) > 512) {
    http_response_code(400);
    echo "token_too_long";
    exit;
}

$tableRes = $conn->query("SHOW TABLES LIKE 'fcm_tokens'");
if (!$tableRes || $tableRes->num_rows === 0) {
    http_response_code(500);
    echo "missing_fcm_tokens_table";
    exit;
}

// 1) If this token already exists, reassign it to the current user.
$tokenStmt = $conn->prepare("SELECT id FROM fcm_tokens WHERE token = ? LIMIT 1");
if (!$tokenStmt) {
    http_response_code(500);
    echo "prepare_token_lookup_failed";
    exit;
}
$tokenStmt->bind_param("s", $token);
$tokenStmt->execute();
$tokenResult = $tokenStmt->get_result();
$tokenRow = $tokenResult ? $tokenResult->fetch_assoc() : null;

if ($tokenRow) {
    $reassignStmt = $conn->prepare("UPDATE fcm_tokens SET user_id = ? WHERE id = ?");
    if (!$reassignStmt) {
        http_response_code(500);
        echo "prepare_token_reassign_failed";
        exit;
    }
    $tokenId = (int)$tokenRow['id'];
    $reassignStmt->bind_param("ii", $user_id, $tokenId);
    if (!$reassignStmt->execute()) {
        http_response_code(500);
        echo "token_reassign_failed:" . $conn->error;
        exit;
    }
    echo "ok";
    exit;
}

// 2) Otherwise update existing row for this user, or insert new row.
$userStmt = $conn->prepare("SELECT id FROM fcm_tokens WHERE user_id = ? LIMIT 1");
if (!$userStmt) {
    http_response_code(500);
    echo "prepare_user_lookup_failed";
    exit;
}
$userStmt->bind_param("i", $user_id);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userRow = $userResult ? $userResult->fetch_assoc() : null;

if ($userRow) {
    $updateStmt = $conn->prepare("UPDATE fcm_tokens SET token = ? WHERE user_id = ?");
    if (!$updateStmt) {
        http_response_code(500);
        echo "prepare_update_failed";
        exit;
    }
    $updateStmt->bind_param("si", $token, $user_id);
    if (!$updateStmt->execute()) {
        http_response_code(500);
        echo "update_failed:" . $conn->error;
        exit;
    }
    echo "ok";
    exit;
}

$insertStmt = $conn->prepare("INSERT INTO fcm_tokens (user_id, token) VALUES (?, ?)");
if (!$insertStmt) {
    http_response_code(500);
    echo "prepare_insert_failed";
    exit;
}

$insertStmt->bind_param("is", $user_id, $token);
if (!$insertStmt->execute() || $insertStmt->affected_rows <= 0) {
    http_response_code(500);
    echo "insert_failed:" . $conn->error;
    exit;
}

echo "ok";
?>
